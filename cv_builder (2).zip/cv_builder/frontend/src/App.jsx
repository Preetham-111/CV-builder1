import { useState, useRef, useEffect, useCallback } from 'react'
import './App.css'

const API_BASE = '/api'

async function apiPost(path, body = {}) {
  const res = await fetch(`${API_BASE}${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
  if (!res.ok) { const err = await res.json().catch(() => ({ detail: res.statusText })); throw new Error(err.detail || 'Request failed') }
  return res.json()
}
async function apiGet(path) {
  const res = await fetch(`${API_BASE}${path}`)
  if (!res.ok) throw new Error('Request failed')
  return res.json()
}

const PHASES = [
  { id: 1, label: 'Identity' }, { id: 2, label: 'Summary' }, { id: 3, label: 'Profile' },
  { id: 4, label: 'Domain' }, { id: 5, label: 'Deep Dive' }, { id: 6, label: 'Template' },
  { id: 7, label: 'Review' }, { id: 8, label: 'Export' },
]

const LANGUAGES = [
  { code: 'en', name: 'English' }, { code: 'es', name: 'Español' },
  { code: 'pt', name: 'Português' }, { code: 'ja', name: '日本語' },
]

// ─── Icons ───
function Icon({ d, size = 20 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={d} /></svg>
}
const FileTextIcon = ({ size }) => <Icon d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M16 13H8 M16 17H8" size={size} />
const SendIcon = () => <Icon d="M22 2L11 13 M22 2l-7 20-4-9-9-4 20-7z" />
const DownloadIcon = () => <Icon d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4 M7 10l5 5 5-5 M12 15V3" size={16} />
const CheckIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
const EditIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
const MicIcon = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" /><path d="M19 10v2a7 7 0 0 1-14 0v-2" /><line x1="12" y1="19" x2="12" y2="23" /><line x1="8" y1="23" x2="16" y2="23" /></svg>
const MicOffIcon = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="1" y1="1" x2="23" y2="23" /><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6" /><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2c0 .87-.17 1.7-.48 2.46" /><line x1="12" y1="19" x2="12" y2="23" /><line x1="8" y1="23" x2="16" y2="23" /></svg>
const GlobeIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><line x1="2" y1="12" x2="22" y2="12" /><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" /></svg>

function App() {
  const [sessionId, setSessionId] = useState(null)
  const [messages, setMessages] = useState([])
  const [currentPhase, setCurrentPhase] = useState(0)
  const [phaseName, setPhaseName] = useState('')
  const [cvSummary, setCvSummary] = useState(null)
  const [conversationState, setConversationState] = useState('')
  const [inputValue, setInputValue] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [selectedTemplate, setSelectedTemplate] = useState('')
  const [suggestedTemplate, setSuggestedTemplate] = useState('')
  const [editingField, setEditingField] = useState(null)
  const [editValue, setEditValue] = useState('')
  const [language, setLanguage] = useState('en')
  const [isListening, setIsListening] = useState(false)
  const [recognition, setRecognition] = useState(null)
  const messagesEndRef = useRef(null)
  const inputRef = useRef(null)

  // ─── Speech-to-Text (Web Speech API) ───
  useEffect(() => {
    if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      const rec = new SpeechRecognition()
      rec.continuous = false
      rec.interimResults = false
      rec.lang = language === 'es' ? 'es-ES' : language === 'pt' ? 'pt-BR' : language === 'ja' ? 'ja-JP' : 'en-US'
      rec.onresult = (e) => {
        const transcript = e.results[0][0].transcript
        setInputValue(prev => prev + transcript)
        setIsListening(false)
      }
      rec.onerror = () => setIsListening(false)
      rec.onend = () => setIsListening(false)
      setRecognition(rec)
    }
  }, [language])

  const toggleListening = useCallback(() => {
    if (!recognition) return
    if (isListening) { recognition.stop(); setIsListening(false) }
    else { recognition.start(); setIsListening(true) }
  }, [recognition, isListening])

  const scrollToBottom = useCallback(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [])
  useEffect(() => { scrollToBottom() }, [messages, scrollToBottom])
  useEffect(() => { if (!loading && inputRef.current) inputRef.current.focus() }, [loading])

  const startSession = async (lang = language) => {
    setLoading(true); setError(null)
    try {
      const data = await apiPost('/session', { language: lang, channel: 'web' })
      setSessionId(data.session_id); setCurrentPhase(data.phase)
      setPhaseName(data.phase_name); setConversationState('conversing'); setLanguage(lang)
      setMessages([{ role: 'bot', content: data.opening_message }])
    } catch (err) { setError('Failed to start session. Is the backend running?') }
    finally { setLoading(false) }
  }

  const sendMessage = async () => {
    const text = inputValue.trim()
    if (!text || !sessionId || loading) return
    setInputValue(''); setLoading(true); setError(null)
    try {
      const data = await apiPost(`/session/${sessionId}/message`, { content: text })
      setMessages(prev => [...prev, { role: 'user', content: text }, { role: 'bot', content: data.response }])
      setCurrentPhase(data.phase); setPhaseName(data.phase_name)
      setConversationState(data.state); setCvSummary(data.cv_summary)
      if (data.cv_summary?.suggested_template) setSuggestedTemplate(data.cv_summary.suggested_template)
    } catch (err) { setError(err.message) }
    finally { setLoading(false) }
  }

  const selectTemplate = async (templateId) => {
    if (!sessionId) return
    setSelectedTemplate(templateId); setLoading(true)
    try {
      await apiPost(`/session/${sessionId}/template`, { template: templateId })
      const names = { simple: 'Simple', postcard: 'Post Card', executive: 'Executive' }
      const data = await apiPost(`/session/${sessionId}/message`, { content: names[templateId] })
      setMessages(prev => [...prev,
        { role: 'user', content: `I'd like the ${names[templateId]} template` },
        { role: 'bot', content: data.response },
      ])
      setCurrentPhase(data.phase); setPhaseName(data.phase_name)
      setConversationState(data.state); setCvSummary(data.cv_summary)
    } catch (err) { setError(err.message) }
    finally { setLoading(false) }
  }

  const exportCV = async (format) => {
    if (!sessionId) return
    try {
      if (format === 'json') {
        const data = await apiGet(`/session/${sessionId}/preview`)
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a'); a.href = url; a.download = 'cv.json'; a.click()
        URL.revokeObjectURL(url)
      } else {
        const res = await fetch(`${API_BASE}/session/${sessionId}/export`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ format }),
        })
        if (!res.ok) throw new Error('Export failed')
        const blob = await res.blob()
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a'); a.href = url; a.download = `cv.${format}`; a.click()
        URL.revokeObjectURL(url)
      }
    } catch (err) { setError(`Export failed: ${err.message}`) }
  }

  const editField = async (field, value) => {
    if (!sessionId) return
    try {
      const data = await apiPost(`/session/${sessionId}/edit`, { field, value })
      setCvSummary(data.cv_summary); setEditingField(null); setEditValue('')
    } catch (err) { setError(`Edit failed: ${err.message}`) }
  }

  const restart = () => {
    setSessionId(null); setMessages([]); setCurrentPhase(0); setPhaseName('')
    setCvSummary(null); setConversationState(''); setInputValue(''); setError(null)
    setSelectedTemplate(''); setSuggestedTemplate('')
  }

  const isTemplatePhase = currentPhase === 6
  const isExportPhase = currentPhase === 8 || conversationState === 'complete'
  const isComplete = conversationState === 'complete'
  const isReviewPhase = currentPhase === 7
  const sttAvailable = typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)

  // ─── Welcome Screen ───
  if (!sessionId) {
    return (
      <div className="app" role="main">
        <header className="app-header" role="banner">
          <div className="logo"><FileTextIcon size={28} /> NTT DATA CV Builder</div>
        </header>
        <div className="welcome-screen">
          <div className="hero-icon" aria-hidden="true"><FileTextIcon size={40} /></div>
          <h1>Build Your NTT DATA CV</h1>
          <p>Create a professional, branded CV through a guided conversation. Supports text and voice input.</p>

          {/* Language Selector */}
          <div className="lang-selector" role="group" aria-label="Language selection">
            <GlobeIcon />
            {LANGUAGES.map(l => (
              <button key={l.code} className={`lang-btn ${language === l.code ? 'active' : ''}`}
                onClick={() => setLanguage(l.code)} aria-pressed={language === l.code}>
                {l.name}
              </button>
            ))}
          </div>

          {error && <div className="error-banner" role="alert">{error}</div>}
          <button className="start-btn" onClick={() => startSession(language)}
            aria-label="Start building your CV">
            Start Building Your CV
          </button>
        </div>
      </div>
    )
  }

  // ─── Chat Screen ───
  return (
    <div className="app" role="main">
      <header className="app-header" role="banner">
        <div className="logo"><FileTextIcon size={24} /> CV Builder</div>
        <span className="subtitle" aria-live="polite">{phaseName ? `Phase: ${phaseName}` : 'Loading...'}</span>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
          <button className="lang-btn small" onClick={() => { restart(); setLanguage(language) }}
            aria-label="Change language" title="Change language">
            <GlobeIcon /> {language.toUpperCase()}
          </button>
          <button onClick={restart} className="restart-btn" aria-label="Restart CV builder">
            Restart
          </button>
        </div>
      </header>

      {/* Progress Bar */}
      <nav className="progress-bar" aria-label="CV creation progress">
        {PHASES.map((phase, idx) => (
          <div key={phase.id} style={{ display: 'flex', alignItems: 'center' }}>
            <div className={`progress-step ${currentPhase === phase.id ? 'active' : currentPhase > phase.id ? 'completed' : ''}`}
              aria-current={currentPhase === phase.id ? 'step' : undefined}>
              <span className="step-num" aria-hidden="true">{currentPhase > phase.id ? <CheckIcon /> : phase.id}</span>
              <span className="step-label">{phase.label}</span>
            </div>
            {idx < PHASES.length - 1 && <div className={`progress-connector ${currentPhase > phase.id ? 'completed' : ''}`} />}
          </div>
        ))}
      </nav>

      <div className="app-main">
        {/* Chat Panel */}
        <div className="chat-panel">
          <div className="chat-messages" role="log" aria-live="polite" aria-label="Chat messages">
            {messages.map((msg, idx) => (
              <div key={idx} className={`message ${msg.role}`} role={msg.role === 'bot' ? 'article' : 'status'}>
                {msg.content}
              </div>
            ))}

            {/* Validation Warnings */}
            {cvSummary?.validation_errors?.length > 0 && isReviewPhase && (
              <div className="validation-warnings" role="alert">
                <strong>Missing fields:</strong>
                {cvSummary.validation_errors.map((e, i) => <div key={i}>- {e}</div>)}
              </div>
            )}

            {/* Template Selection */}
            {isTemplatePhase && (
              <div className="message bot" role="group" aria-label="Template selection">
                <strong>Select a Template:</strong>
                {suggestedTemplate && (
                  <div className="suggestion-badge" aria-label="Suggested template">
                    Suggested: {{ simple: 'Simple', postcard: 'Post Card', executive: 'Executive' }[suggestedTemplate]}
                  </div>
                )}
                <div className="template-selector">
                  {[
                    { id: 'simple', name: 'Simple', desc: 'Clean, professional layout. Best for technical roles.' },
                    { id: 'postcard', name: 'Post Card', desc: 'Centered layout with side accent. Modern and visual.' },
                    { id: 'executive', name: 'Executive', desc: 'Bold headings, double bars. Best for leadership roles.' },
                  ].map(t => (
                    <div key={t.id}
                      className={`template-option ${selectedTemplate === t.id ? 'selected' : ''} ${suggestedTemplate === t.id ? 'suggested' : ''}`}
                      onClick={() => selectTemplate(t.id)}
                      role="button" tabIndex={0} aria-label={`${t.name} template: ${t.desc}`}
                      onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); selectTemplate(t.id) } }}>
                      <div className="name">{t.name} {suggestedTemplate === t.id && <span className="badge">Recommended</span>}</div>
                      <div className="desc">{t.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Export UI */}
            {isExportPhase && (
              <div className="message bot" role="group" aria-label="Export options">
                <strong>Your CV is ready!</strong> Download in your preferred format:
                <div className="export-actions">
                  <button className="export-btn" onClick={() => exportCV('pdf')} aria-label="Download PDF"><DownloadIcon /> PDF</button>
                  <button className="export-btn" onClick={() => exportCV('docx')} aria-label="Download DOCX"><DownloadIcon /> DOCX</button>
                  <button className="export-btn" onClick={() => exportCV('json')} aria-label="Download JSON"><DownloadIcon /> JSON</button>
                </div>
                {isComplete && (
                  <div style={{ marginTop: 12 }}>
                    <button className="export-btn" style={{ background: 'var(--ntt-magenta)', color: 'white' }}
                      onClick={restart}>Build Another CV</button>
                  </div>
                )}
              </div>
            )}

            {loading && <div className="typing-indicator" aria-label="Bot is typing"><span /><span /><span /></div>}
            {error && <div className="error-banner" role="alert">{error}</div>}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input — hidden during template/export */}
          {!isTemplatePhase && !isExportPhase && (
            <div className="chat-input-area">
              <div className="chat-input-wrapper">
                <textarea
                  ref={inputRef} className="chat-input" value={inputValue}
                  onChange={e => setInputValue(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() } }}
                  placeholder={isReviewPhase ? 'Type "generate" to proceed, or click fields to edit...' : 'Type your answer...'}
                  rows={1} disabled={loading} aria-label="Your answer"
                />
              </div>
              {/* STT Mic Button */}
              {sttAvailable && (
                <button className={`mic-btn ${isListening ? 'listening' : ''}`}
                  onClick={toggleListening} disabled={loading}
                  aria-label={isListening ? 'Stop voice input' : 'Start voice input'}
                  title={isListening ? 'Stop listening' : 'Speak your answer'}>
                  {isListening ? <MicOffIcon /> : <MicIcon />}
                </button>
              )}
              <button className="send-btn" onClick={sendMessage} disabled={loading || !inputValue.trim()}
                aria-label="Send message"><SendIcon /></button>
            </div>
          )}
        </div>

        {/* Side Panel — CV Preview */}
        {cvSummary && (
          <aside className="side-panel" aria-label="CV Preview">
            <h3>CV Preview</h3>

            {cvSummary.identity && (
              <div className="preview-card">
                <div className="label">Identity</div>
                {isReviewPhase ? (
                  <div className="review-section">
                    {Object.entries(cvSummary.identity).map(([k, v]) => v ? (
                      <div key={k} className="review-field">
                        <span className="field-label">{k.replace(/_/g, ' ')}</span>
                        {editingField === `identity.${k}` ? (
                          <div style={{ display: 'flex', gap: 4 }}>
                            <input className="edit-input" value={editValue}
                              onChange={e => setEditValue(e.target.value)}
                              onKeyDown={e => { if (e.key === 'Enter') editField(`identity.${k}`, editValue); if (e.key === 'Escape') { setEditingField(null); setEditValue('') } }}
                              autoFocus aria-label={`Edit ${k}`} />
                            <button onClick={() => editField(`identity.${k}`, editValue)} className="save-btn">Save</button>
                          </div>
                        ) : (
                          <div className="field-value" onClick={() => { setEditingField(`identity.${k}`); setEditValue(v) }}
                            role="button" tabIndex={0} aria-label={`Edit ${k}: ${v}`}>
                            <EditIcon /> {v}
                          </div>
                        )}
                      </div>
                    ) : null)}
                  </div>
                ) : (
                  Object.entries(cvSummary.identity).filter(([, v]) => v).map(([k, v]) => (
                    <div key={k} className="value"><strong>{k.replace(/_/g, ' ')}:</strong> {v}</div>
                  ))
                )}
              </div>
            )}

            {cvSummary.summary && (cvSummary.summary.profile_summary || cvSummary.summary.target_roles) && (
              <div className="preview-card">
                <div className="label">Professional Summary</div>
                {isReviewPhase ? (
                  <div className="review-section">
                    {cvSummary.summary.profile_summary && (
                      <div className="review-field">
                        <span className="field-label">Profile Summary</span>
                        {editingField === 'summary.profile_summary' ? (
                          <div style={{ display: 'flex', gap: 4 }}>
                            <input className="edit-input" value={editValue} onChange={e => setEditValue(e.target.value)}
                              onKeyDown={e => { if (e.key === 'Enter') editField('summary.profile_summary', editValue); if (e.key === 'Escape') { setEditingField(null); setEditValue('') } }}
                              autoFocus />
                            <button onClick={() => editField('summary.profile_summary', editValue)} className="save-btn">Save</button>
                          </div>
                        ) : (
                          <div className="field-value" onClick={() => { setEditingField('summary.profile_summary'); setEditValue(cvSummary.summary.profile_summary) }}>
                            <EditIcon /> {cvSummary.summary.profile_summary}
                          </div>
                        )}
                      </div>
                    )}
                    {cvSummary.summary.target_roles && (
                      <div className="review-field">
                        <span className="field-label">Target Roles</span>
                        {editingField === 'summary.target_roles' ? (
                          <div style={{ display: 'flex', gap: 4 }}>
                            <input className="edit-input" value={editValue} onChange={e => setEditValue(e.target.value)}
                              onKeyDown={e => { if (e.key === 'Enter') editField('summary.target_roles', editValue); if (e.key === 'Escape') { setEditingField(null); setEditValue('') } }}
                              autoFocus />
                            <button onClick={() => editField('summary.target_roles', editValue)} className="save-btn">Save</button>
                          </div>
                        ) : (
                          <div className="field-value" onClick={() => { setEditingField('summary.target_roles'); setEditValue(cvSummary.summary.target_roles) }}>
                            <EditIcon /> {cvSummary.summary.target_roles}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    {cvSummary.summary.profile_summary && <div className="value">{cvSummary.summary.profile_summary}</div>}
                    {cvSummary.summary.target_roles && <div className="value"><strong>Target:</strong> {cvSummary.summary.target_roles}</div>}
                  </>
                )}
              </div>
            )}

            {cvSummary.profile && (cvSummary.profile.current_role || cvSummary.profile.current_organization) && (
              <div className="preview-card">
                <div className="label">Profile</div>
                {isReviewPhase ? (
                  <div className="review-section">
                    {Object.entries(cvSummary.profile).map(([k, v]) => v ? (
                      <div key={k} className="review-field">
                        <span className="field-label">{k.replace(/_/g, ' ')}</span>
                        {editingField === `profile.${k}` ? (
                          <div style={{ display: 'flex', gap: 4 }}>
                            <input className="edit-input" value={editValue} onChange={e => setEditValue(e.target.value)}
                              onKeyDown={e => { if (e.key === 'Enter') editField(`profile.${k}`, editValue); if (e.key === 'Escape') { setEditingField(null); setEditValue('') } }}
                              autoFocus />
                            <button onClick={() => editField(`profile.${k}`, editValue)} className="save-btn">Save</button>
                          </div>
                        ) : (
                          <div className="field-value" onClick={() => { setEditingField(`profile.${k}`); setEditValue(v) }}>
                            <EditIcon /> {v}
                          </div>
                        )}
                      </div>
                    ) : null)}
                  </div>
                ) : (
                  <>
                    {cvSummary.profile.current_role && <div className="value"><strong>Role:</strong> {cvSummary.profile.current_role}</div>}
                    {cvSummary.profile.current_organization && <div className="value"><strong>Org:</strong> {cvSummary.profile.current_organization}</div>}
                    {cvSummary.profile.current_location && <div className="value"><strong>Location:</strong> {cvSummary.profile.current_location}</div>}
                  </>
                )}
              </div>
            )}

            {cvSummary.domain && (cvSummary.domain.industries_domains || cvSummary.domain.core_expertise || cvSummary.domain.key_skills) && (
              <div className="preview-card">
                <div className="label">Domain &amp; Expertise</div>
                {isReviewPhase ? (
                  <div className="review-section">
                    {Object.entries(cvSummary.domain).map(([k, v]) => v ? (
                      <div key={k} className="review-field">
                        <span className="field-label">{k.replace(/_/g, ' ')}</span>
                        {editingField === `domain.${k}` ? (
                          <div style={{ display: 'flex', gap: 4 }}>
                            <input className="edit-input" value={editValue} onChange={e => setEditValue(e.target.value)}
                              onKeyDown={e => { if (e.key === 'Enter') editField(`domain.${k}`, editValue); if (e.key === 'Escape') { setEditingField(null); setEditValue('') } }}
                              autoFocus />
                            <button onClick={() => editField(`domain.${k}`, editValue)} className="save-btn">Save</button>
                          </div>
                        ) : (
                          <div className="field-value" onClick={() => { setEditingField(`domain.${k}`); setEditValue(v) }}>
                            <EditIcon /> {v}
                          </div>
                        )}
                      </div>
                    ) : null)}
                  </div>
                ) : (
                  <>
                    {cvSummary.domain.industries_domains && <div className="value"><strong>Industries:</strong> {cvSummary.domain.industries_domains}</div>}
                    {cvSummary.domain.core_expertise && <div className="value"><strong>Expertise:</strong> {cvSummary.domain.core_expertise}</div>}
                    {cvSummary.domain.key_skills && <div className="value"><strong>Skills:</strong> {cvSummary.domain.key_skills}</div>}
                  </>
                )}
              </div>
            )}

            {cvSummary.deep_dive && cvSummary.deep_dive.answers && Object.keys(cvSummary.deep_dive.answers).length > 0 && (
              <div className="preview-card">
                <div className="label">{cvSummary.deep_dive.role_title || 'Role'} Deep Dive</div>
                {cvSummary.deep_dive.focus && <div className="value" style={{ fontSize: 11, color: 'var(--ntt-magenta)' }}>Focus: {cvSummary.deep_dive.focus}</div>}
                {isReviewPhase ? (
                  <div className="review-section">
                    {Object.entries(cvSummary.deep_dive.answers).map(([q, a]) => (
                      <div key={q} className="review-field">
                        <span className="field-label">{q}</span>
                        {editingField === `deep_dive.answers.${q}` ? (
                          <div style={{ display: 'flex', gap: 4 }}>
                            <input className="edit-input" value={editValue} onChange={e => setEditValue(e.target.value)}
                              onKeyDown={e => { if (e.key === 'Enter') editField(`deep_dive.answers.${q}`, editValue); if (e.key === 'Escape') { setEditingField(null); setEditValue('') } }}
                              autoFocus />
                            <button onClick={() => editField(`deep_dive.answers.${q}`, editValue)} className="save-btn">Save</button>
                          </div>
                        ) : (
                          <div className="field-value" onClick={() => { setEditingField(`deep_dive.answers.${q}`); setEditValue(a) }}>
                            <EditIcon /> {a}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  Object.entries(cvSummary.deep_dive.answers).map(([q, a]) => (
                    <div key={q} className="value"><strong>{q}:</strong> {a}</div>
                  ))
                )}
              </div>
            )}

            {cvSummary.template && (
              <div className="preview-card">
                <div className="label">Template</div>
                <div className="value">{{ simple: 'Simple', postcard: 'Post Card', executive: 'Executive' }[cvSummary.template] || cvSummary.template}</div>
              </div>
            )}
          </aside>
        )}
      </div>
    </div>
  )
}

export default App