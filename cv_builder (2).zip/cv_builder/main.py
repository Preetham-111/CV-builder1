"""FastAPI backend — NTT DATA Conversational CV Builder."""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from config import (
    PORT, HOST, TEMPLATE_NAMES, SUPPORTED_LANGUAGES, DEFAULT_LANGUAGE,
    PHASE_NAMES, NTT_LOGO_PATH,
)
from core.models import CVData, ConversationState, TemplateInfo
from core.conversation import (
    create_session, process_user_message, get_current_prompt,
    get_cv_summary, apply_edit, OPENING_MESSAGE,
)
from generators.pdf_gen import generate_pdf, generate_pdf_bytes
from generators.docx_gen import generate_docx, generate_docx_bytes

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------- App setup ----------

app = FastAPI(
    title="NTT DATA CV Builder",
    description="Conversational CV Builder with AI-powered guided prompts",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory session store (use Redis/DB for production)
_sessions: dict[str, ConversationState] = {}


# ---------- Request/Response models ----------

class StartSessionRequest(BaseModel):
    language: str = DEFAULT_LANGUAGE


class EditFieldRequest(BaseModel):
    field: str
    value: str


class ExportRequest(BaseModel):
    format: str = "pdf"  # pdf, docx, json


# ---------- REST endpoints ----------

@app.get("/")
async def root():
    return {"message": "NTT DATA CV Builder API", "version": "1.0.0"}


@app.get("/api/health")
async def health():
    return {"status": "ok"}


@app.post("/api/session", response_model=dict)
async def start_session(req: StartSessionRequest = StartSessionRequest()):
    """Create a new conversation session."""
    if req.language not in SUPPORTED_LANGUAGES:
        req.language = DEFAULT_LANGUAGE
    state = create_session(language=req.language)
    _sessions[state.session_id] = state
    return {
        "session_id": state.session_id,
        "opening_message": OPENING_MESSAGE,
        "phase": state.current_phase,
        "phase_name": PHASE_NAMES.get(state.current_phase, ""),
    }


@app.get("/api/session/{session_id}")
async def get_session(session_id: str):
    """Get current session state and CV data summary."""
    state = _sessions.get(session_id)
    if not state:
        raise HTTPException(404, "Session not found")
    return {
        "session_id": state.session_id,
        "phase": state.current_phase,
        "phase_name": PHASE_NAMES.get(state.current_phase, ""),
        "state": state.state,
        "current_question_index": state.current_question_index,
        "cv_summary": get_cv_summary(state),
        "language": state.language,
    }


@app.delete("/api/session/{session_id}")
async def delete_session(session_id: str):
    """Delete a session."""
    if session_id in _sessions:
        del _sessions[session_id]
    return {"status": "deleted"}


@app.post("/api/session/{session_id}/message")
async def send_message(session_id: str, message: dict):
    """Send a text message and get the bot response (REST fallback for WebSocket)."""
    state = _sessions.get(session_id)
    if not state:
        raise HTTPException(404, "Session not found")

    user_text = message.get("content", "")
    if not user_text.strip():
        raise HTTPException(400, "Empty message")

    response = process_user_message(state, user_text)
    return {
        "response": response,
        "phase": state.current_phase,
        "phase_name": PHASE_NAMES.get(state.current_phase, ""),
        "state": state.state,
        "cv_summary": get_cv_summary(state),
    }


@app.get("/api/templates")
async def list_templates():
    """List available CV templates."""
    templates = [
        TemplateInfo(
            id="simple",
            name="Simple",
            description="Clean, professional layout with minimal decoration. Best for technical roles.",
        ),
        TemplateInfo(
            id="postcard",
            name="Post Card",
            description="Centered layout with side accent stripe. Modern and visually appealing.",
        ),
        TemplateInfo(
            id="executive",
            name="Executive",
            description="Large headings, double top bars, bold branding. Best for senior/leadership roles.",
        ),
    ]
    return [t.model_dump() for t in templates]


@app.post("/api/session/{session_id}/template")
async def set_template(session_id: str, body: dict):
    """Set the CV template for a session."""
    state = _sessions.get(session_id)
    if not state:
        raise HTTPException(404, "Session not found")
    template_id = body.get("template", "simple")
    if template_id not in TEMPLATE_NAMES:
        raise HTTPException(400, f"Unknown template: {template_id}")
    state.cv_data.template = template_id
    return {"template": template_id}


@app.post("/api/session/{session_id}/edit")
async def edit_cv_field(session_id: str, req: EditFieldRequest):
    """Edit a specific CV field during review."""
    state = _sessions.get(session_id)
    if not state:
        raise HTTPException(404, "Session not found")
    result = apply_edit(state, req.field, req.value)
    return {"result": result, "cv_summary": get_cv_summary(state)}


@app.post("/api/session/{session_id}/export")
async def export_cv(session_id: str, req: ExportRequest):
    """Generate and download the CV in the requested format."""
    state = _sessions.get(session_id)
    if not state:
        raise HTTPException(404, "Session not found")

    cv = state.cv_data
    fmt = req.format.lower()

    if fmt == "json":
        summary = get_cv_summary(state)
        return JSONResponse(content=summary)

    try:
        if fmt == "pdf":
            path = generate_pdf(cv)
            media_type = "application/pdf"
            filename = f"{cv.identity.full_name.replace(' ', '_') or 'cv'}.pdf"
        elif fmt == "docx":
            path = generate_docx(cv)
            media_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            filename = f"{cv.identity.full_name.replace(' ', '_') or 'cv'}.docx"
        else:
            raise HTTPException(400, f"Unsupported format: {fmt}")

        return FileResponse(
            path=str(path),
            media_type=media_type,
            filename=filename,
        )
    except Exception as e:
        logger.error(f"Export error: {e}")
        raise HTTPException(500, f"Generation failed: {str(e)}")


@app.get("/api/session/{session_id}/preview")
async def preview_cv(session_id: str):
    """Get a JSON preview of the CV data (for frontend rendering)."""
    state = _sessions.get(session_id)
    if not state:
        raise HTTPException(404, "Session not found")
    return get_cv_summary(state)


@app.get("/api/languages")
async def list_languages():
    """List supported languages."""
    lang_names = {"en": "English", "es": "Espa\u00f1ol", "pt": "Portugu\u00eas", "ja": "\u65e5\u672c\u8a9e"}
    return [{"code": code, "name": lang_names.get(code, code)} for code in SUPPORTED_LANGUAGES]


@app.get("/api/logo")
async def get_logo():
    """Serve the NTT DATA logo."""
    if NTT_LOGO_PATH.exists():
        return FileResponse(str(NTT_LOGO_PATH), media_type="image/png")
    raise HTTPException(404, "Logo not found")


# ---------- WebSocket endpoint ----------

@app.websocket("/ws/{session_id}")
async def websocket_chat(websocket: WebSocket, session_id: str):
    """Real-time WebSocket chat for the CV builder conversation."""
    await websocket.accept()
    logger.info(f"WebSocket connected: {session_id}")

    # Get or create session
    state = _sessions.get(session_id)
    if not state:
        state = create_session()
        _sessions[state.session_id] = state
        # Send opening message
        await websocket.send_json({
            "type": "bot",
            "content": OPENING_MESSAGE,
            "phase": state.current_phase,
            "phase_name": PHASE_NAMES.get(state.current_phase, ""),
        })

    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            user_text = msg.get("content", "")

            if not user_text.strip():
                continue

            # Process user message
            response = process_user_message(state, user_text)

            # Send bot response
            await websocket.send_json({
                "type": "bot",
                "content": response,
                "phase": state.current_phase,
                "phase_name": PHASE_NAMES.get(state.current_phase, ""),
                "state": state.state,
                "cv_summary": get_cv_summary(state),
            })

    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected: {session_id}")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        await websocket.close()


# ---------- Run ----------

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host=HOST, port=PORT, reload=True)