"""Template definitions for CV layouts."""

from config import TEMPLATE_SIMPLE, TEMPLATE_POSTCARD, TEMPLATE_EXECUTIVE, TEMPLATE_NAMES