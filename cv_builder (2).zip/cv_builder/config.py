"""Configuration constants for NTT DATA CV Builder."""

import os
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).parent
ASSETS_DIR = BASE_DIR / "assets"
OUTPUT_DIR = BASE_DIR / "output"
LOCALES_DIR = BASE_DIR / "locales"
TEMPLATES_DIR = BASE_DIR / "templates"
FRONTEND_DIR = BASE_DIR / "frontend"

# NTT DATA Branding
NTT_BRAND = {
    "primary_color": "#A3238E",       # NTT DATA magenta
    "secondary_color": "#004B87",     # NTT DATA dark blue
    "accent_color": "#6C2F91",        # Purple accent
    "light_bg": "#F5F0F6",           # Light magenta tint for sections
    "header_bar_color": "#A3238E",   # Header bar
    "text_color": "#333333",          # Body text
    "footer_text": "NTT DATA - Confidential",
}

# Logo paths
NTT_LOGO_PATH = ASSETS_DIR / "ntt_data_logo.png"

# Gemini LLM Settings (free tier)
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
GEMINI_MAX_TOKENS = 1024
GEMINI_TEMPERATURE = 0.3

# Role matching
FUZZY_MATCH_THRESHOLD = 80

# Conversation phases
PHASE_IDENTITY = 1
PHASE_SUMMARY = 2
PHASE_PROFILE = 3
PHASE_DOMAIN = 4
PHASE_DEEP_DIVE = 5
PHASE_TEMPLATE = 6
PHASE_REVIEW = 7
PHASE_EXPORT = 8

PHASE_NAMES = {
    1: "Identity & Profile",
    2: "Professional Summary",
    3: "Basic Profile",
    4: "Domain & Expertise",
    5: "Role-Specific Deep Dive",
    6: "Template Selection",
    7: "Review & Edit",
    8: "Export",
}

# Conversation states
STATE_CONVERSING = "conversing"
STATE_REVIEW = "review"
STATE_EXPORT = "export"
STATE_COMPLETE = "complete"

# Supported languages
SUPPORTED_LANGUAGES = ["en", "es", "pt", "ja"]
DEFAULT_LANGUAGE = "en"

# CV Template types
TEMPLATE_SIMPLE = "simple"
TEMPLATE_POSTCARD = "postcard"
TEMPLATE_EXECUTIVE = "executive"

TEMPLATE_NAMES = {
    "simple": "Simple",
    "postcard": "Post Card",
    "executive": "Executive",
}

# Role-specific deep dive question sets
ROLE_QUESTIONS = {
    "Senior Team Lead": {
        "focus": "execution + team handling + technical delivery",
        "questions": [
            "What type of projects have you led?",
            "What was your role in project execution?",
            "How did you manage your team's performance?",
            "What technologies/tools did your team use?",
            "How did you handle delivery challenges?",
            "Did you mentor or coach team members?",
            "How did you ensure code quality or delivery quality?",
            "Have you handled sprint planning or agile ceremonies?",
            "What improvements did you bring to your team?",
            "What measurable impact did your team deliver?",
        ],
    },
    "Project Manager": {
        "focus": "planning, delivery, risk, stakeholders",
        "questions": [
            "What project management methodologies have you used (Agile, Waterfall, Hybrid)?",
            "How many projects have you managed simultaneously?",
            "What was the average project size (budget/team)?",
            "How do you handle project risks and issues?",
            "How do you manage stakeholders and expectations?",
            "Have you handled client communication directly?",
            "How do you track project progress and KPIs?",
            "What tools have you used (JIRA, MS Project, etc.)?",
            "What is your biggest project success story?",
            "Have you delivered projects under tight deadlines or constraints?",
        ],
    },
    "Technical Manager": {
        "focus": "architecture + technical decisions + team",
        "questions": [
            "What are your primary technical domains?",
            "Have you designed system architectures? Please describe.",
            "What kind of systems have you built (scalable, distributed, cloud)?",
            "Which technologies and platforms do you specialize in?",
            "How do you make technical decisions?",
            "Have you reviewed code or set technical standards?",
            "How do you ensure system performance and scalability?",
            "Have you worked with cloud platforms (AWS, Azure, GCP)?",
            "How do you handle technical risks?",
            "Have you mentored engineers or technical leads?",
        ],
    },
    "Senior HR": {
        "focus": "people, policies, talent strategy",
        "questions": [
            "What HR functions do you specialize in (recruitment, L&D, HRBP, etc.)?",
            "Have you handled end-to-end recruitment cycles?",
            "What is your experience with employee engagement initiatives?",
            "Have you worked on performance management systems?",
            "Have you handled conflict resolution or employee relations?",
            "What HR tools/systems have you used?",
            "Have you worked on HR policies or compliance?",
            "What hiring volume have you handled?",
            "Have you supported leadership or business units directly?",
            "What HR transformations or initiatives have you led?",
        ],
    },
    "Delivery Head": {
        "focus": "large-scale delivery, strategy, financials",
        "questions": [
            "What is the size of delivery you have managed (teams, revenue)?",
            "Have you handled multiple accounts or programs?",
            "What is your experience in P&L management?",
            "How do you ensure delivery excellence across projects?",
            "Have you driven digital transformation or large programs?",
            "How do you manage client relationships at leadership level?",
            "How do you handle escalations and crisis situations?",
            "What governance models have you implemented?",
            "What business growth or revenue impact have you driven?",
            "How do you align delivery with business strategy?",
        ],
    },
}

# Fuzzy-match aliases for roles
ROLE_ALIASES = {
    "Senior Team Lead": ["senior team lead", "team lead", "stl", "lead"],
    "Project Manager": ["project manager", "pm", "project mgr"],
    "Technical Manager": ["technical manager", "tech manager", "tech mgr", "tm"],
    "Senior HR": ["senior hr", "hr", "hr manager", "hr lead", "human resources"],
    "Delivery Head": ["delivery head", "dh", "delivery manager", "head of delivery"],
}

# Server settings
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))