"""Generate NTT DATA CV Builder Presentation — branded PPTX."""

from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

# ── Brand colours ──
MAGENTA = RGBColor(0xA3, 0x23, 0x8E)
BLUE    = RGBColor(0x00, 0x4B, 0x87)
PURPLE  = RGBColor(0x6C, 0x2F, 0x91)
WHITE   = RGBColor(0xFF, 0xFF, 0xFF)
DARK    = RGBColor(0x33, 0x33, 0x33)
GREY    = RGBColor(0x66, 0x66, 0x66)
LIGHT_BG = RGBColor(0xF5, 0xF0, 0xF6)

SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)

ASSETS = Path(__file__).parent / "assets"
LOGO   = ASSETS / "ntt_data_logo.png"
OUT    = Path(__file__).parent / "NTT_DATA_CV_Builder_Presentation.pptx"


def _set_bg(slide, color):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color


def _add_shape(slide, left, top, width, height, color, shape_type=MSO_SHAPE.RECTANGLE):
    shape = slide.shapes.add_shape(shape_type, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    return shape


def _add_textbox(slide, left, top, width, height, text, font_size=18,
                 color=DARK, bold=False, alignment=PP_ALIGN.LEFT, font_name="Calibri"):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = color
    p.font.bold = bold
    p.font.name = font_name
    p.alignment = alignment
    return txBox


def _add_bullet_slide(slide, left, top, width, height, items, font_size=16,
                      color=DARK, spacing=Pt(6)):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    for i, item in enumerate(items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = item
        p.font.size = Pt(font_size)
        p.font.color.rgb = color
        p.font.name = "Calibri"
        p.space_after = spacing
        p.level = 0
        # Add bullet
        pPr = p._pPr
        if pPr is None:
            from pptx.oxml.ns import qn
            pPr = p._p.get_or_add_pPr()
        from pptx.oxml.ns import qn
        buChar = pPr.makeelement(qn('a:buChar'), {})
        buChar.set('char', '●')
        pPr.append(buChar)
    return txBox


def _add_top_bar(slide, color=MAGENTA, height=Inches(0.08)):
    _add_shape(slide, Inches(0), Inches(0), SLIDE_W, height, color)


def _add_bottom_bar(slide, color=BLUE, height=Inches(0.06)):
    _add_shape(slide, Inches(0), SLIDE_H - height, SLIDE_W, height, color)


def _add_footer(slide, text="NTT DATA — Confidential"):
    _add_bottom_bar(slide)
    _add_textbox(slide, Inches(0.5), SLIDE_H - Inches(0.55), Inches(12), Inches(0.4),
                 text, font_size=9, color=GREY, alignment=PP_ALIGN.LEFT)


# ═══════════════════════════════════════════════
# SLIDE BUILDERS
# ═══════════════════════════════════════════════

def slide_title(prs):
    """Slide 1: Title."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank
    _set_bg(slide, WHITE)

    # Full magenta header band
    _add_shape(slide, Inches(0), Inches(0), SLIDE_W, Inches(3.2), MAGENTA)

    # Logo
    if LOGO.exists():
        slide.shapes.add_picture(str(LOGO), Inches(0.8), Inches(0.6), height=Inches(0.8))

    # Title
    _add_textbox(slide, Inches(0.8), Inches(1.6), Inches(11), Inches(1.2),
                 "Conversational CV Builder", font_size=42, color=WHITE, bold=True)

    # Subtitle
    _add_textbox(slide, Inches(0.8), Inches(2.5), Inches(11), Inches(0.6),
                 "AI-Powered Guided Resume Creation for NTT DATA", font_size=20, color=WHITE)

    # Bottom info
    _add_textbox(slide, Inches(0.8), Inches(3.8), Inches(6), Inches(0.5),
                 "NTT DATA Internal Tool", font_size=16, color=BLUE, bold=True)
    _add_textbox(slide, Inches(0.8), Inches(4.4), Inches(6), Inches(0.5),
                 "FastAPI  •  React  •  Gemini AI  •  ReportLab  •  python-docx",
                 font_size=13, color=GREY)

    # Decorative accent box
    _add_shape(slide, Inches(0.8), Inches(5.2), Inches(4), Inches(0.06), PURPLE)

    _add_footer(slide)


def slide_agenda(prs):
    """Slide 2: Agenda."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(6), Inches(0.8),
                 "Agenda", font_size=36, color=MAGENTA, bold=True)

    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    items = [
        "Problem Statement & Motivation",
        "Solution Overview",
        "Architecture & Tech Stack",
        "Conversational Flow — 8 Phases",
        "Role-Specific Deep Dive",
        "CV Templates — Simple / Post Card / Executive",
        "Key Features — Chat, Preview, Edit, Export",
        "Demo Walkthrough",
        "Future Enhancements",
    ]
    _add_bullet_slide(slide, Inches(0.8), Inches(1.5), Inches(10), Inches(5.5),
                      items, font_size=18, color=DARK, spacing=Pt(8))
    _add_footer(slide)


def slide_problem(prs):
    """Slide 3: Problem Statement."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
                 "Problem Statement", font_size=36, color=MAGENTA, bold=True)
    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    # Left column — Problems
    _add_shape(slide, Inches(0.8), Inches(1.6), Inches(5.5), Inches(5), LIGHT_BG)
    _add_textbox(slide, Inches(1.0), Inches(1.7), Inches(5), Inches(0.5),
                 "Challenges Today", font_size=22, color=MAGENTA, bold=True)
    problems = [
        "Manual CV creation is time-consuming & inconsistent",
        "Employees struggle with formatting & branding guidelines",
        "Different orgs produce CVs with varying quality",
        "No role-specific guidance — generic templates only",
        "Review cycles are slow — back-and-forth with managers",
        "Updating CVs across teams is unmanageable",
    ]
    _add_bullet_slide(slide, Inches(1.0), Inches(2.3), Inches(5), Inches(4),
                      problems, font_size=15, color=DARK)

    # Right column — Impact
    _add_shape(slide, Inches(6.8), Inches(1.6), Inches(5.5), Inches(5), RGBColor(0xE8, 0xF5, 0xE9))
    _add_textbox(slide, Inches(7.0), Inches(1.7), Inches(5), Inches(0.5),
                 "Impact", font_size=22, color=RGBColor(0x2E, 0x7D, 0x32), bold=True)
    impact = [
        "Delayed proposal submissions",
        "Inconsistent NTT DATA branding",
        "Poor first impression with clients",
        "Lost revenue opportunities",
        "Frustrated employees & managers",
    ]
    _add_bullet_slide(slide, Inches(7.0), Inches(2.3), Inches(5), Inches(4),
                      impact, font_size=15, color=DARK)
    _add_footer(slide)


def slide_solution(prs):
    """Slide 4: Solution Overview."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(10), Inches(0.8),
                 "Solution Overview", font_size=36, color=MAGENTA, bold=True)
    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    # Main description
    _add_textbox(slide, Inches(0.8), Inches(1.5), Inches(11), Inches(0.8),
                 "A conversational, AI-guided CV builder that walks employees through each section\n"
                 "step-by-step, producing professional NTT DATA-branded CVs in minutes.",
                 font_size=18, color=DARK)

    # Feature cards
    cards = [
        ("Conversational UI", "Guided chat interface\nwalks you through\neach section", MAGENTA),
        ("AI-Powered", "Gemini AI enhances\ncontent for impact\n& professionalism", PURPLE),
        ("Role-Specific", "Deep dive questions\ntailored to your\nrole & focus area", BLUE),
        ("3 Templates", "Simple, Post Card,\n& Executive layouts\nwith NTT DATA branding", RGBColor(0x2E, 0x7D, 0x32)),
        ("Instant Export", "PDF, DOCX, or JSON\n— download your\nCV in seconds", RGBColor(0xE6, 0x5C, 0x00)),
    ]

    x_start = Inches(0.8)
    card_w = Inches(2.2)
    card_h = Inches(2.8)
    gap = Inches(0.25)

    for i, (title, desc, color) in enumerate(cards):
        x = x_start + i * (card_w + gap)
        y = Inches(3.0)
        # Card background
        shape = _add_shape(slide, x, y, card_w, card_h, WHITE)
        shape.shadow.inherit = False
        shape.line.color.rgb = color
        shape.line.width = Pt(2)
        # Color accent bar at top of card
        _add_shape(slide, x, y, card_w, Inches(0.06), color)
        # Title
        _add_textbox(slide, x + Inches(0.15), y + Inches(0.2), card_w - Inches(0.3), Inches(0.5),
                     title, font_size=15, color=color, bold=True, alignment=PP_ALIGN.CENTER)
        # Description
        _add_textbox(slide, x + Inches(0.15), y + Inches(0.75), card_w - Inches(0.3), Inches(2),
                     desc, font_size=12, color=GREY, alignment=PP_ALIGN.CENTER)

    _add_footer(slide)


def _add_box(slide, left, top, width, height, title, subtitle, color, title_size=13, sub_size=9):
    """Add a styled architecture box with title + subtitle."""
    shape = _add_shape(slide, left, top, width, height, WHITE)
    shape.line.color.rgb = color
    shape.line.width = Pt(1.5)
    # Color accent bar on top
    _add_shape(slide, left, top, width, Inches(0.05), color)
    # Title
    _add_textbox(slide, left + Inches(0.08), top + Inches(0.08), width - Inches(0.16), Inches(0.32),
                 title, font_size=title_size, color=color, bold=True, alignment=PP_ALIGN.CENTER)
    # Subtitle
    _add_textbox(slide, left + Inches(0.06), top + Inches(0.38), width - Inches(0.12), height - Inches(0.46),
                 subtitle, font_size=sub_size, color=GREY, alignment=PP_ALIGN.CENTER)


def _add_arrow_right(slide, left, top, width=Inches(0.4), color=MAGENTA):
    """Add a right-pointing arrow connector shape."""
    arrow = slide.shapes.add_shape(
        MSO_SHAPE.RIGHT_ARROW, left, top, width, Inches(0.25)
    )
    arrow.fill.solid()
    arrow.fill.fore_color.rgb = color
    arrow.line.fill.background()
    return arrow


def _add_arrow_down(slide, left, top, height=Inches(0.35), color=MAGENTA):
    """Add a downward-pointing arrow connector shape."""
    arrow = slide.shapes.add_shape(
        MSO_SHAPE.DOWN_ARROW, left, top, Inches(0.25), height
    )
    arrow.fill.solid()
    arrow.fill.fore_color.rgb = color
    arrow.line.fill.background()
    return arrow


def _add_dashed_line(slide, left, top, width, color=GREY):
    """Add a dashed horizontal line (using a thin shape)."""
    shape = _add_shape(slide, left, top, width, Inches(0.015), color)
    return shape


def slide_architecture(prs):
    """Slide 5: Architecture Diagram."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(10), Inches(0.8),
                 "System Architecture", font_size=36, color=MAGENTA, bold=True)
    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    # ══════════════════════════════════════════
    # LAYER 1 — USER / CLIENT LAYER (top)
    # ══════════════════════════════════════════
    layer_y = Inches(1.45)
    # Layer label
    _add_shape(slide, Inches(0.3), layer_y, Inches(1.6), Inches(0.3), MAGENTA)
    _add_textbox(slide, Inches(0.3), layer_y, Inches(1.6), Inches(0.3),
                 "CLIENT LAYER", font_size=9, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    # Browser box
    _add_box(slide, Inches(2.2), layer_y, Inches(2.6), Inches(1.1),
             "Browser", "React 19 + Vite\nChat UI • Progress Bar\nPreview Panel • Export", BLUE)

    # WebSocket label
    _add_arrow_right(slide, Inches(4.9), layer_y + Inches(0.25), Inches(0.5), PURPLE)
    _add_textbox(slide, Inches(4.95), layer_y + Inches(0.05), Inches(0.5), Inches(0.22),
                 "WS", font_size=7, color=PURPLE, bold=True, alignment=PP_ALIGN.CENTER)

    # REST label
    _add_arrow_right(slide, Inches(4.9), layer_y + Inches(0.65), Inches(0.5), MAGENTA)
    _add_textbox(slide, Inches(4.85), layer_y + Inches(0.45), Inches(0.6), Inches(0.22),
                 "REST", font_size=7, color=MAGENTA, bold=True, alignment=PP_ALIGN.CENTER)

    # ══════════════════════════════════════════
    # LAYER 2 — API GATEWAY (middle-top)
    # ══════════════════════════════════════════
    api_x = Inches(5.5)
    api_y = layer_y
    _add_box(slide, api_x, api_y, Inches(3.2), Inches(1.1),
             "FastAPI Server", "REST + WebSocket\nCORS • Session Mgmt\nuvicorn", MAGENTA)

    # ══════════════════════════════════════════
    # LAYER 3 — CORE ENGINE (middle)
    # ══════════════════════════════════════════
    core_y = Inches(2.85)
    _add_shape(slide, Inches(0.3), core_y, Inches(1.6), Inches(0.3), PURPLE)
    _add_textbox(slide, Inches(0.3), core_y, Inches(1.6), Inches(0.3),
                 "CORE ENGINE", font_size=9, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    # Down arrows from API to core
    _add_arrow_down(slide, api_x + Inches(0.9), api_y + Inches(1.1), Inches(0.3), MAGENTA)
    _add_arrow_down(slide, api_x + Inches(1.7), api_y + Inches(1.1), Inches(0.3), MAGENTA)

    # Conversation Engine
    _add_box(slide, Inches(2.2), core_y + Inches(0.35), Inches(2.4), Inches(1.0),
             "Conversation Engine", "8-Phase State Machine\nQuestion Sequencer\nParse & Advance", PURPLE)

    # Role Matcher
    _add_box(slide, Inches(5.0), core_y + Inches(0.35), Inches(2.2), Inches(1.0),
             "Role Matcher", "Fuzzy Matching\nrapidfuzz • Aliases\nAuto-Detect Role", BLUE)

    # Gemini AI
    _add_box(slide, Inches(7.5), core_y + Inches(0.35), Inches(2.2), Inches(1.0),
             "Gemini AI", "Content Enhancement\nGrammar Polish\nProfessional Wording", RGBColor(0xE6, 0x5C, 0x00))

    # Horizontal connectors between core boxes
    _add_arrow_right(slide, Inches(4.65), core_y + Inches(0.7), Inches(0.35), PURPLE)
    _add_arrow_right(slide, Inches(7.25), core_y + Inches(0.7), Inches(0.25), BLUE)

    # ══════════════════════════════════════════
    # LAYER 4 — DATA & TEMPLATES (bottom)
    # ══════════════════════════════════════════
    data_y = Inches(4.5)
    _add_shape(slide, Inches(0.3), data_y, Inches(1.6), Inches(0.3), RGBColor(0x2E, 0x7D, 0x32))
    _add_textbox(slide, Inches(0.3), data_y, Inches(1.6), Inches(0.3),
                 "DATA LAYER", font_size=9, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    # Down arrows from core to data
    _add_arrow_down(slide, Inches(3.2), core_y + Inches(1.35), Inches(0.3), PURPLE)
    _add_arrow_down(slide, Inches(5.9), core_y + Inches(1.35), Inches(0.3), BLUE)

    # Pydantic Models
    _add_box(slide, Inches(2.2), data_y + Inches(0.35), Inches(2.2), Inches(1.0),
             "Pydantic Models", "CVData • Identity\nProfile • Domain\nDeepDive • Session", RGBColor(0x2E, 0x7D, 0x32))

    # Session Store
    _add_box(slide, Inches(4.7), data_y + Inches(0.35), Inches(2.2), Inches(1.0),
             "Session Store", "In-Memory Dict\n(Redis for Prod)\nSession ID keyed", RGBColor(0x7B, 0x1F, 0xA2))

    # Down arrows from core to generators
    _add_arrow_down(slide, Inches(8.4), core_y + Inches(1.35), Inches(0.3), MAGENTA)

    # ══════════════════════════════════════════
    # LAYER 5 — GENERATORS (right-bottom)
    # ══════════════════════════════════════════
    _add_shape(slide, Inches(0.3), Inches(5.9), Inches(1.6), Inches(0.3), RGBColor(0xE6, 0x5C, 0x00))
    _add_textbox(slide, Inches(0.3), Inches(5.9), Inches(1.6), Inches(0.3),
                 "GENERATORS", font_size=9, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    gen_y = Inches(5.9)
    # PDF Generator
    _add_box(slide, Inches(2.2), gen_y + Inches(0.35), Inches(2.5), Inches(0.8),
             "PDF Generator", "ReportLab • A4 • Branding\n3 Templates", RGBColor(0xC6, 0x28, 0x28))

    # DOCX Generator
    _add_box(slide, Inches(5.0), gen_y + Inches(0.35), Inches(2.5), Inches(0.8),
             "DOCX Generator", "python-docx • Branding\n3 Templates", BLUE)

    # JSON Export
    _add_box(slide, Inches(7.8), gen_y + Inches(0.35), Inches(2.0), Inches(0.8),
             "JSON Export", "Pydantic Dump\nAPI Response", RGBColor(0x2E, 0x7D, 0x32))

    # Arrows from data to generators
    _add_arrow_down(slide, Inches(3.1), data_y + Inches(1.35), Inches(0.3), RGBColor(0xC6, 0x28, 0x28))
    _add_arrow_down(slide, Inches(5.9), data_y + Inches(1.35), Inches(0.3), BLUE)

    # ══════════════════════════════════════════
    # OUTPUT (far right)
    # ══════════════════════════════════════════
    # Arrow from API to output
    _add_arrow_right(slide, Inches(8.8), layer_y + Inches(0.35), Inches(0.6), MAGENTA)
    _add_box(slide, Inches(9.5), layer_y, Inches(2.5), Inches(1.1),
             "Output", "PDF File\nDOCX File\nJSON Data", RGBColor(0xE6, 0x5C, 0x00))

    # ══════════════════════════════════════════
    # Side annotation — Gemini (external service)
    # ══════════════════════════════════════════
    _add_arrow_right(slide, Inches(9.75), core_y + Inches(0.65), Inches(0.5), RGBColor(0xE6, 0x5C, 0x00))
    _add_box(slide, Inches(10.3), core_y + Inches(0.35), Inches(2.2), Inches(1.0),
             "Google Gemini", "gemini-2.0-flash\nFree Tier API\nAI Enhancement", RGBColor(0xE6, 0x5C, 0x00))

    # Dashed boundary lines for layers
    _add_dashed_line(slide, Inches(2.0), layer_y + Inches(1.25), Inches(11.2))
    _add_dashed_line(slide, Inches(2.0), core_y + Inches(0.05), Inches(11.2))
    _add_dashed_line(slide, Inches(2.0), data_y + Inches(0.05), Inches(9.5))
    _add_dashed_line(slide, Inches(2.0), gen_y + Inches(0.05), Inches(9.5))

    _add_footer(slide)


def slide_flow(prs):
    """Slide 6: Conversation Flow."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(10), Inches(0.8),
                 "Conversational Flow — 8 Phases", font_size=36, color=MAGENTA, bold=True)
    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    phases = [
        ("1", "Identity", "Name, Portal ID,\nYears of Experience", MAGENTA),
        ("2", "Summary", "Professional Profile,\nTarget Roles", MAGENTA),
        ("3", "Profile", "Current Role,\nOrganization, Location", PURPLE),
        ("4", "Domain", "Industries, Expertise,\nKey Skills", PURPLE),
        ("5", "Deep Dive", "Role-Specific Questions\n(10 targeted)", BLUE),
        ("6", "Template", "Simple / Post Card\n/ Executive", BLUE),
        ("7", "Review", "Edit Fields,\nVerify Data", RGBColor(0x2E, 0x7D, 0x32)),
        ("8", "Export", "PDF / DOCX /\nJSON Download", RGBColor(0x2E, 0x7D, 0x32)),
    ]

    card_w = Inches(1.35)
    card_h = Inches(2.6)
    x_start = Inches(0.5)
    y = Inches(1.7)
    gap = Inches(0.2)

    for i, (num, title, desc, color) in enumerate(phases):
        x = x_start + i * (card_w + gap)
        # Card
        shape = _add_shape(slide, x, y, card_w, card_h, WHITE)
        shape.line.color.rgb = color
        shape.line.width = Pt(1.5)
        # Number circle
        circle = _add_shape(slide, x + Inches(0.42), y + Inches(0.12), Inches(0.5), Inches(0.5),
                            color, MSO_SHAPE.OVAL)
        circle_tf = circle.text_frame
        circle_tf.paragraphs[0].text = num
        circle_tf.paragraphs[0].font.size = Pt(16)
        circle_tf.paragraphs[0].font.color.rgb = WHITE
        circle_tf.paragraphs[0].font.bold = True
        circle_tf.paragraphs[0].alignment = PP_ALIGN.CENTER
        circle_tf.word_wrap = False
        # Title
        _add_textbox(slide, x + Inches(0.05), y + Inches(0.7), card_w - Inches(0.1), Inches(0.5),
                     title, font_size=12, color=color, bold=True, alignment=PP_ALIGN.CENTER)
        # Description
        _add_textbox(slide, x + Inches(0.05), y + Inches(1.2), card_w - Inches(0.1), Inches(1.3),
                     desc, font_size=10, color=GREY, alignment=PP_ALIGN.CENTER)

        # Arrow between cards
        if i < len(phases) - 1:
            arrow_x = x + card_w + Inches(0.02)
            _add_textbox(slide, arrow_x, y + Inches(1.0), Inches(0.18), Inches(0.4),
                         "→", font_size=16, color=GREY, alignment=PP_ALIGN.CENTER)

    # Bottom note
    _add_textbox(slide, Inches(0.8), Inches(5.0), Inches(11), Inches(1.5),
                 "How it works:\n"
                 "1. User starts a session → greeted with opening message\n"
                 "2. Bot asks one question at a time, phase by phase\n"
                 "3. Deep Dive phase adapts questions based on the user's role (matched via fuzzy search)\n"
                 "4. User selects a template, reviews & edits, then exports",
                 font_size=13, color=GREY)
    _add_footer(slide)


def slide_deep_dive(prs):
    """Slide 7: Role-Specific Deep Dive."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(10), Inches(0.8),
                 "Role-Specific Deep Dive", font_size=36, color=MAGENTA, bold=True)
    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    _add_textbox(slide, Inches(0.8), Inches(1.4), Inches(11), Inches(0.5),
                 "The system automatically detects the user's role and asks 10 targeted questions.",
                 font_size=16, color=DARK)

    roles = [
        ("Senior Team Lead", "execution + team handling\n+ technical delivery", MAGENTA),
        ("Project Manager", "planning, delivery,\nrisk, stakeholders", BLUE),
        ("Technical Manager", "architecture + technical\ndecisions + team", PURPLE),
        ("Senior HR", "people, policies,\ntalent strategy", RGBColor(0xE6, 0x5C, 0x00)),
        ("Delivery Head", "large-scale delivery,\nstrategy, financials", RGBColor(0x2E, 0x7D, 0x32)),
    ]

    card_w = Inches(2.2)
    card_h = Inches(2.2)
    x_start = Inches(0.6)
    gap = Inches(0.25)

    for i, (role, focus, color) in enumerate(roles):
        x = x_start + i * (card_w + gap)
        y = Inches(2.2)
        shape = _add_shape(slide, x, y, card_w, card_h, WHITE)
        shape.line.color.rgb = color
        shape.line.width = Pt(2)
        _add_shape(slide, x, y, card_w, Inches(0.06), color)
        _add_textbox(slide, x + Inches(0.1), y + Inches(0.15), card_w - Inches(0.2), Inches(0.5),
                     role, font_size=13, color=color, bold=True, alignment=PP_ALIGN.CENTER)
        _add_textbox(slide, x + Inches(0.1), y + Inches(0.6), card_w - Inches(0.2), Inches(0.4),
                     "Focus:", font_size=10, color=GREY, alignment=PP_ALIGN.CENTER)
        _add_textbox(slide, x + Inches(0.1), y + Inches(0.95), card_w - Inches(0.2), Inches(1.1),
                     focus, font_size=11, color=DARK, alignment=PP_ALIGN.CENTER)

    # Fuzzy matching note
    _add_textbox(slide, Inches(0.8), Inches(4.8), Inches(11), Inches(1.2),
                 "Fuzzy Matching: Users don't need to type the exact role title. The system uses\n"
                 "rapidfuzz to match aliases and near-matches (e.g. \"team lead\" → \"Senior Team Lead\",\n"
                 "\"PM\" → \"Project Manager\") with a configurable threshold.",
                 font_size=14, color=DARK)

    _add_footer(slide)


def slide_templates(prs):
    """Slide 8: CV Templates."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(10), Inches(0.8),
                 "CV Template Designs", font_size=36, color=MAGENTA, bold=True)
    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    templates = [
        ("Simple", "Clean, professional layout",
         "• Minimal decoration\n• Best for technical roles\n• Straightforward sections\n• Magenta top bar",
         MAGENTA),
        ("Post Card", "Centered layout with side accent",
         "• Centered name & header\n• Purple side accent stripe\n• Modern & visual\n• Best for mid-level roles",
         PURPLE),
        ("Executive", "Bold headings, double bars",
         "• Large name heading\n• Double top bars (magenta + blue)\n• Bold section titles\n• Best for senior/leadership",
         BLUE),
    ]

    card_w = Inches(3.5)
    card_h = Inches(4.5)
    x_start = Inches(0.8)
    gap = Inches(0.5)

    for i, (name, desc, features, color) in enumerate(templates):
        x = x_start + i * (card_w + gap)
        y = Inches(1.5)
        shape = _add_shape(slide, x, y, card_w, card_h, WHITE)
        shape.line.color.rgb = color
        shape.line.width = Pt(2)
        # Header band
        _add_shape(slide, x, y, card_w, Inches(0.8), color)
        _add_textbox(slide, x + Inches(0.2), y + Inches(0.15), card_w - Inches(0.4), Inches(0.5),
                     name, font_size=24, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
        # Description
        _add_textbox(slide, x + Inches(0.2), y + Inches(0.95), card_w - Inches(0.4), Inches(0.6),
                     desc, font_size=14, color=DARK, alignment=PP_ALIGN.CENTER)
        # Features
        _add_textbox(slide, x + Inches(0.2), y + Inches(1.7), card_w - Inches(0.4), Inches(2.5),
                     features, font_size=13, color=GREY)

    # Common branding note
    _add_textbox(slide, Inches(0.8), Inches(6.3), Inches(11), Inches(0.5),
                 "All templates include: NTT DATA logo, magenta branding, footer confidentiality line, A4 format",
                 font_size=13, color=BLUE, bold=True)

    _add_footer(slide)


def slide_features(prs):
    """Slide 9: Key Features."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(10), Inches(0.8),
                 "Key Features", font_size=36, color=MAGENTA, bold=True)
    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    features = [
        ("Conversational UX", "Step-by-step guided chat. No forms to fill — just answer naturally.", MAGENTA),
        ("Live Preview", "Side panel shows CV data as you build. See changes in real time.", PURPLE),
        ("Edit in Place", "Click any field during Review to edit. No need to start over.", BLUE),
        ("AI Enhancement", "Gemini polishes wording, fixes grammar, and adds impact (optional).", RGBColor(0x2E, 0x7D, 0x32)),
        ("Multi-Format Export", "Download as PDF, DOCX, or JSON — whatever the business needs.", RGBColor(0xE6, 0x5C, 0x00)),
        ("Branded Output", "NTT DATA logo, colors, and footer on every generated document.", RGBColor(0x7B, 0x1F, 0xA2)),
    ]

    for i, (title, desc, color) in enumerate(features):
        row = i // 2
        col = i % 2
        x = Inches(0.8) + col * Inches(6)
        y = Inches(1.5) + row * Inches(1.6)

        # Color accent dot
        _add_shape(slide, x, y + Inches(0.1), Inches(0.15), Inches(0.15), color, MSO_SHAPE.OVAL)
        _add_textbox(slide, x + Inches(0.3), y, Inches(5.5), Inches(0.4),
                     title, font_size=18, color=color, bold=True)
        _add_textbox(slide, x + Inches(0.3), y + Inches(0.4), Inches(5.5), Inches(0.6),
                     desc, font_size=13, color=GREY)

    _add_footer(slide)


def slide_api(prs):
    """Slide 10: API Endpoints."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(10), Inches(0.8),
                 "API Endpoints", font_size=36, color=MAGENTA, bold=True)
    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    # REST endpoints
    _add_textbox(slide, Inches(0.8), Inches(1.5), Inches(5.5), Inches(0.5),
                 "REST API", font_size=20, color=BLUE, bold=True)

    endpoints = [
        ("POST", "/api/session", "Create a new conversation session"),
        ("GET",  "/api/session/{id}", "Get session state & CV summary"),
        ("DELETE", "/api/session/{id}", "Delete a session"),
        ("POST", "/api/session/{id}/message", "Send a message & get bot response"),
        ("POST", "/api/session/{id}/template", "Set CV template"),
        ("POST", "/api/session/{id}/edit", "Edit a CV field during review"),
        ("POST", "/api/session/{id}/export", "Export CV (PDF / DOCX / JSON)"),
        ("GET",  "/api/session/{id}/preview", "Get JSON preview of CV data"),
        ("GET",  "/api/templates", "List available templates"),
        ("GET",  "/api/languages", "List supported languages"),
        ("GET",  "/api/logo", "Serve NTT DATA logo"),
    ]

    y = Inches(2.0)
    for method, path, desc in endpoints:
        method_color = {
            "GET": RGBColor(0x2E, 0x7D, 0x32),
            "POST": BLUE,
            "DELETE": RGBColor(0xC6, 0x28, 0x28),
        }.get(method, DARK)

        _add_textbox(slide, Inches(0.8), y, Inches(0.8), Inches(0.3),
                     method, font_size=10, color=method_color, bold=True)
        _add_textbox(slide, Inches(1.7), y, Inches(3.5), Inches(0.3),
                     path, font_size=10, color=DARK)
        _add_textbox(slide, Inches(5.3), y, Inches(3.5), Inches(0.3),
                     desc, font_size=10, color=GREY)
        y += Inches(0.32)

    # WebSocket
    _add_textbox(slide, Inches(7.5), Inches(1.5), Inches(5), Inches(0.5),
                 "WebSocket", font_size=20, color=PURPLE, bold=True)

    _add_shape(slide, Inches(7.5), Inches(2.2), Inches(4.8), Inches(3), LIGHT_BG)
    ws_items = [
        "ws://{host}/ws/{session_id}",
        "Real-time bidirectional chat",
        "Messages: { content: \"...\" }",
        "Responses: type, content, phase,",
        "  phase_name, state, cv_summary",
        "",
        "Fallback: REST /api/session/{id}/message",
        "for environments without WebSocket",
    ]
    _add_bullet_slide(slide, Inches(7.7), Inches(2.4), Inches(4.4), Inches(2.6),
                      ws_items, font_size=12, color=DARK, spacing=Pt(3))

    _add_footer(slide)


def slide_demo(prs):
    """Slide 11: Demo Walkthrough."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(10), Inches(0.8),
                 "Demo Walkthrough", font_size=36, color=MAGENTA, bold=True)
    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    steps = [
        ("1", "Start", "User opens the app and clicks \"Start Building Your CV\"", MAGENTA),
        ("2", "Identity", "Enters name, portal ID, and years of experience", MAGENTA),
        ("3", "Summary", "Describes professional profile and target roles", PURPLE),
        ("4", "Profile", "Provides current role, organization, and location", PURPLE),
        ("5", "Domain", "Lists industries, core expertise, and key skills", BLUE),
        ("6", "Deep Dive", "Answers 10 role-specific questions (auto-detected)", BLUE),
        ("7", "Template", "Selects Simple / Post Card / Executive layout", RGBColor(0x2E, 0x7D, 0x32)),
        ("8", "Review", "Reviews all data, edits any field inline", RGBColor(0x2E, 0x7D, 0x32)),
        ("9", "Export", "Downloads branded CV as PDF, DOCX, or JSON", RGBColor(0xE6, 0x5C, 0x00)),
    ]

    y = Inches(1.5)
    for num, phase, desc, color in steps:
        # Number badge
        circle = _add_shape(slide, Inches(0.8), y, Inches(0.35), Inches(0.35), color, MSO_SHAPE.OVAL)
        circle_tf = circle.text_frame
        circle_tf.paragraphs[0].text = num
        circle_tf.paragraphs[0].font.size = Pt(12)
        circle_tf.paragraphs[0].font.color.rgb = WHITE
        circle_tf.paragraphs[0].font.bold = True
        circle_tf.paragraphs[0].alignment = PP_ALIGN.CENTER

        # Phase name
        _add_textbox(slide, Inches(1.3), y - Inches(0.02), Inches(1.5), Inches(0.4),
                     phase, font_size=14, color=color, bold=True)
        # Description
        _add_textbox(slide, Inches(2.8), y - Inches(0.02), Inches(9), Inches(0.4),
                     desc, font_size=13, color=DARK)

        y += Inches(0.52)

    # Side note
    _add_shape(slide, Inches(0.8), y + Inches(0.3), Inches(11.5), Inches(1.2), LIGHT_BG)
    _add_textbox(slide, Inches(1.0), y + Inches(0.4), Inches(11), Inches(1),
                 "Live Preview: The CV preview panel on the right updates in real time as the user answers each question.\n"
                 "Edit-in-Place: During the Review phase, clicking any field allows inline editing without restarting.",
                 font_size=13, color=DARK)
    _add_footer(slide)


def slide_future(prs):
    """Slide 12: Future Enhancements."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)
    _add_top_bar(slide)

    _add_textbox(slide, Inches(0.8), Inches(0.4), Inches(10), Inches(0.8),
                 "Future Enhancements", font_size=36, color=MAGENTA, bold=True)
    _add_shape(slide, Inches(0.8), Inches(1.1), Inches(3), Inches(0.04), MAGENTA)

    items = [
        "Gemini AI Enhancement — auto-polish CV content for impact & professionalism",
        "Multi-language Support — English, Español, Português, 日本語 (config ready)",
        "Redis / Database Sessions — persistent storage replacing in-memory store",
        "Authentication — SSO / NTT DATA corporate login integration",
        "PDF Preview — rendered preview directly in the browser before download",
        "Photo Upload — employee photo integration in CV header",
        "Project Portfolio — detailed project descriptions with tech stacks",
        "Education & Certifications — dedicated sections for qualifications",
        "Admin Dashboard — analytics on CV generation, popular templates, roles",
        "Bulk Export — generate CVs for an entire team from a spreadsheet",
    ]
    _add_bullet_slide(slide, Inches(0.8), Inches(1.5), Inches(11), Inches(5.5),
                      items, font_size=15, color=DARK, spacing=Pt(6))
    _add_footer(slide)


def slide_thank_you(prs):
    """Slide 13: Thank You."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _set_bg(slide, WHITE)

    # Full magenta background
    _add_shape(slide, Inches(0), Inches(0), SLIDE_W, SLIDE_H, MAGENTA)

    # Logo
    if LOGO.exists():
        slide.shapes.add_picture(str(LOGO), Inches(5.5), Inches(1.5), height=Inches(1))

    _add_textbox(slide, Inches(0.8), Inches(2.8), Inches(11.7), Inches(1.2),
                 "Thank You!", font_size=48, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    _add_textbox(slide, Inches(0.8), Inches(4.0), Inches(11.7), Inches(0.8),
                 "NTT DATA Conversational CV Builder", font_size=24, color=WHITE, alignment=PP_ALIGN.CENTER)

    _add_shape(slide, Inches(5.5), Inches(5.0), Inches(2.3), Inches(0.04), WHITE)

    _add_textbox(slide, Inches(0.8), Inches(5.3), Inches(11.7), Inches(0.6),
                 "Building professional CVs through guided conversation",
                 font_size=16, color=WHITE, alignment=PP_ALIGN.CENTER)


def main():
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H

    slide_title(prs)
    slide_agenda(prs)
    slide_problem(prs)
    slide_solution(prs)
    slide_architecture(prs)
    slide_flow(prs)
    slide_deep_dive(prs)
    slide_templates(prs)
    slide_features(prs)
    slide_api(prs)
    slide_demo(prs)
    slide_future(prs)
    slide_thank_you(prs)

    prs.save(str(OUT))
    print(f"Presentation saved to: {OUT}")


if __name__ == "__main__":
    main()