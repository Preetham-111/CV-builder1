"""Fuzzy role matching — maps user's role title to predefined role categories."""

from config import ROLE_ALIASES, FUZZY_MATCH_THRESHOLD


def match_role(user_role: str) -> str | None:
    """Match a user-provided role string to one of the predefined role categories.

    Uses case-insensitive substring and fuzzy matching.
    Returns the canonical role name or None.
    """
    if not user_role:
        return None

    lower = user_role.lower().strip()

    # Exact substring match first
    for canonical, aliases in ROLE_ALIASES.items():
        for alias in aliases:
            if alias in lower or lower in alias:
                return canonical

    # Fuzzy match
    try:
        from rapidfuzz import fuzz
        best_score = 0
        best_role = None
        for canonical, aliases in ROLE_ALIASES.items():
            for alias in aliases:
                score = fuzz.ratio(lower, alias)
                if score > best_score:
                    best_score = score
                    best_role = canonical
        if best_score >= FUZZY_MATCH_THRESHOLD:
            return best_role
    except ImportError:
        pass  # rapidfuzz not installed, skip fuzzy matching

    return None