"""Google Gemini AI client — free tier conversational engine."""

from __future__ import annotations

import json
import logging
from typing import Optional

from config import GEMINI_API_KEY, GEMINI_MODEL, GEMINI_TEMPERATURE, GEMINI_MAX_TOKENS

logger = logging.getLogger(__name__)

_client = None


def _get_client():
    """Lazy-initialize the Gemini client."""
    global _client
    if _client is not None:
        return _client

    if not GEMINI_API_KEY:
        logger.warning("GEMINI_API_KEY not set — conversational AI features disabled")
        return None

    try:
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_API_KEY)
        _client = genai
        return _client
    except ImportError:
        logger.error("google-generativeai package not installed")
        return None


def chat_with_gemini(
    system_prompt: str,
    conversation_history: list[dict[str, str]],
    user_message: str,
) -> str:
    """Send a message to Gemini and get a response.

    Args:
        system_prompt: Instructions for the AI (role, behavior, constraints).
        conversation_history: List of {"role": "user"/"model", "content": "..."} dicts.
        user_message: The latest user message.

    Returns:
        The AI's text response, or an empty string on failure.
    """
    client = _get_client()
    if client is None:
        return ""

    try:
        model = client.GenerativeModel(
            model_name=GEMINI_MODEL,
            system_instruction=system_prompt,
            generation_config=client.types.GenerationConfig(
                temperature=GEMINI_TEMPERATURE,
                max_output_tokens=GEMINI_MAX_TOKENS,
            ),
        )

        # Build the chat history in Gemini format
        gemini_history = []
        for msg in conversation_history:
            role = "user" if msg["role"] == "user" else "model"
            gemini_history.append({
                "role": role,
                "parts": [msg["content"]],
            })

        chat = model.start_chat(history=gemini_history)
        response = chat.send_message(user_message)
        return response.text or ""

    except Exception as e:
        logger.error(f"Gemini API error: {e}")
        return ""


def enhance_cv_content(cv_data: dict) -> dict:
    """Use Gemini to polish/enhance the CV content.

    Takes the raw CV data dict and returns an enhanced version with
    improved wording, grammar fixes, and professional formatting.
    """
    client = _get_client()
    if client is None:
        return cv_data

    prompt = (
        "You are a professional CV writer for NTT DATA. "
        "Take the following CV data and enhance the content: improve wording, "
        "fix grammar, make it more professional and impactful. "
        "Return ONLY valid JSON with the same structure, no markdown fences."
    )

    try:
        model = client.GenerativeModel(
            model_name=GEMINI_MODEL,
            system_instruction=prompt,
            generation_config=client.types.GenerationConfig(
                temperature=0.2,
                max_output_tokens=2048,
                response_mime_type="application/json",
            ),
        )

        response = model.generate_content(json.dumps(cv_data, indent=2))

        if response.text:
            enhanced = json.loads(response.text)
            return enhanced
    except Exception as e:
        logger.error(f"Gemini enhancement error: {e}")

    return cv_data


def is_available() -> bool:
    """Check if Gemini is configured and available."""
    return bool(GEMINI_API_KEY)