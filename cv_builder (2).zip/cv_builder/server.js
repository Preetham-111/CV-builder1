/**
 * NTT DATA CV Builder — Node.js Express Backend
 * Features: rule-based conversation, role deep dive, STT, template suggestion,
 * validation, review/edit, multilingual, messaging webhooks, PDF/DOCX/JSON export.
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── OpenAI Placeholder (activate with OPENAI_API_KEY env var) ───
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
async function chatWithOpenAI(systemPrompt, history, userMessage) {
  if (!OPENAI_API_KEY) return '';
  try {
    const openai = require('openai');
    const client = new openai.default({ apiKey: OPENAI_API_KEY });
    const messages = [{ role: 'system', content: systemPrompt }, ...history, { role: 'user', content: userMessage }];
    const resp = await client.chat.completions.create({ model: 'gpt-4o-mini', messages, max_tokens: 1024, temperature: 0.3 });
    return resp.choices[0]?.message?.content || '';
  } catch (err) { console.error('OpenAI error:', err.message); return ''; }
}

// ─── Middleware ───
app.use(cors());
app.use(express.json({ limit: '10mb' })); // large for audio payloads

const frontendDist = path.join(__dirname, 'frontend', 'dist');
if (fs.existsSync(frontendDist)) app.use(express.static(frontendDist));

const OUTPUT_DIR = path.join(__dirname, 'output');
if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR, { recursive: true });

// ─── Branding ───
const NTT_BRAND = {
  primary_color: '#A3238E', secondary_color: '#004B87', accent_color: '#6C2F91',
  light_bg: '#F5F0F6', text_color: '#333333', footer_text: 'NTT DATA - Confidential',
};

// ─── Multilingual Prompts ───
const I18N = {
  en: {
    opening: 'Hi — I can help you build a CV. Shall we start?',
    identity: ['What is your full name as it should appear on the CV?', 'What is your portal ID?', 'What are your total years of experience?'],
    summary: ['How would you describe your professional profile in 2 to 3 lines?', 'What kinds of roles are you targeting?'],
    profile: ['What is your current role/title?', 'What is your current organization?', 'What is your current location?'],
    domain: ['Which industries or domains have you worked in?', 'What are your core areas of expertise?', 'What are your key skills (technical or functional)?'],
    template_msg: "Great! We've covered all the content. Now let's pick a template.\nWould you like a **Simple**, **Post Card**, or **Executive** layout?",
    review_msg: "Here's a summary of your CV data. You can edit any field or say **generate** to proceed.",
    export_msg: 'I\'ll generate your CV. Which format — **PDF**, **DOCX**, or **JSON**?',
    review_complete: "I'll generate your CV using the {template} template. Do you want to review it first or go ahead?",
  },
  es: {
    opening: '¡Hola! Puedo ayudarte a crear tu CV. ¿Empezamos?',
    identity: ['¿Cuál es tu nombre completo tal como debe aparecer en el CV?', '¿Cuál es tu ID de portal?', '¿Cuántos años de experiencia tienes?'],
    summary: ['¿Cómo describirías tu perfil profesional en 2 o 3 líneas?', '¿Qué tipo de roles buscas?'],
    profile: ['¿Cuál es tu cargo/rol actual?', '¿Cuál es tu organización actual?', '¿Cuál es tu ubicación actual?'],
    domain: ['¿En qué industrias o dominios has trabajado?', '¿Cuáles son tus áreas de expertise?', '¿Cuáles son tus habilidades clave?'],
    template_msg: '¡Genial! Ya cubrimos todo. Ahora elige una plantilla.\n¿Te gustaría **Simple**, **Post Card** o **Executive**?',
    review_msg: 'Aquí está el resumen de tu CV. Puedes editar cualquier campo o decir **generar** para continuar.',
    export_msg: 'Generaré tu CV. ¿Qué formato prefieres — **PDF**, **DOCX** o **JSON**?',
    review_complete: "Generaré tu CV con la plantilla {template}. ¿Quieres revisarlo primero o continuar?",
  },
  pt: {
    opening: 'Olá! Posso ajudá-lo a criar seu CV. Vamos começar?',
    identity: ['Qual é o seu nome completo como deve aparecer no CV?', 'Qual é o seu ID de portal?', 'Quantos anos de experiência você tem?'],
    summary: ['Como você descreveria seu perfil profissional em 2 ou 3 linhas?', 'Que tipos de cargos você procura?'],
    profile: ['Qual é o seu cargo/função atual?', 'Qual é a sua organização atual?', 'Qual é a sua localização atual?'],
    domain: ['Em quais indústrias ou domínios você trabalhou?', 'Quais são suas áreas de especialização?', 'Quais são suas habilidades principais?'],
    template_msg: 'Ótimo! Cobrimos todo o conteúdo. Agora vamos escolher um modelo.\nVocê gostaria de **Simple**, **Post Card** ou **Executive**?',
    review_msg: 'Aqui está o resumo do seu CV. Você pode editar qualquer campo ou dizer **gerar** para prosseguir.',
    export_msg: 'Vou gerar seu CV. Qual formato — **PDF**, **DOCX** ou **JSON**?',
    review_complete: "Vou gerar seu CV com o modelo {template}. Deseja revisá-lo primeiro ou continuar?",
  },
  ja: {
    opening: 'こんにちは—CVの作成をお手伝いします。始めましょうか？',
    identity: ['CVに記載するフルネームは何ですか？', 'ポータルIDは何ですか？', '総経験年数は何年ですか？'],
    summary: ['2〜3行でプロフィールを説明してください', 'どのような役職を希望していますか？'],
    profile: ['現在の役職は何ですか？', '現在の組織は何ですか？', '現在の場所はどこですか？'],
    domain: ['どの業界やドメインで働きましたか？', 'コア専門分野は何ですか？', '主要なスキルは何ですか？'],
    template_msg: 'すべての内容が完了しました。テンプレートを選びましょう。\n**Simple**、**Post Card**、**Executive**のどれがよろしいですか？',
    review_msg: 'CVデータの要約です。フィールドを編集するか、**generate**と言って続行してください。',
    export_msg: 'CVを生成します。形式は**PDF**、**DOCX**、**JSON**のどれがよろしいですか？',
    review_complete: "{template}テンプレートでCVを生成します。先に確認しますか、それともそのまま進めますか？",
  },
};

function t(lang, key) { return (I18N[lang] && I18N[lang][key]) || I18N.en[key]; }

// ─── Role Deep Dive Questions ───
const ROLE_QUESTIONS = {
  'Senior Team Lead': {
    focus: 'execution + team handling + technical delivery',
    questions: [
      'What type of projects have you led?', 'What was your role in project execution?',
      'How did you manage your team\'s performance?', 'What technologies/tools did your team use?',
      'How did you handle delivery challenges?', 'Did you mentor or coach team members?',
      'How did you ensure code quality or delivery quality?', 'Have you handled sprint planning or agile ceremonies?',
      'What improvements did you bring to your team?', 'What measurable impact did your team deliver?',
    ],
  },
  'Project Manager': {
    focus: 'planning, delivery, risk, stakeholders',
    questions: [
      'What project management methodologies have you used (Agile, Waterfall, Hybrid)?',
      'How many projects have you managed simultaneously?', 'What was the average project size (budget/team)?',
      'How do you handle project risks and issues?', 'How do you manage stakeholders and expectations?',
      'Have you handled client communication directly?', 'How do you track project progress and KPIs?',
      'What tools have you used (JIRA, MS Project, etc.)?', 'What is your biggest project success story?',
      'Have you delivered projects under tight deadlines or constraints?',
    ],
  },
  'Technical Manager': {
    focus: 'architecture + technical decisions + team',
    questions: [
      'What are your primary technical domains?', 'Have you designed system architectures? Please describe.',
      'What kind of systems have you built (scalable, distributed, cloud)?',
      'Which technologies and platforms do you specialize in?', 'How do you make technical decisions?',
      'Have you reviewed code or set technical standards?', 'How do you ensure system performance and scalability?',
      'Have you worked with cloud platforms (AWS, Azure, GCP)?', 'How do you handle technical risks?',
      'Have you mentored engineers or technical leads?',
    ],
  },
  'Senior HR': {
    focus: 'people, policies, talent strategy',
    questions: [
      'What HR functions do you specialize in (recruitment, L&D, HRBP, etc.)?',
      'Have you handled end-to-end recruitment cycles?', 'What is your experience with employee engagement initiatives?',
      'Have you worked on performance management systems?', 'Have you handled conflict resolution or employee relations?',
      'What HR tools/systems have you used?', 'Have you worked on HR policies or compliance?',
      'What hiring volume have you handled?', 'Have you supported leadership or business units directly?',
      'What HR transformations or initiatives have you led?',
    ],
  },
  'Delivery Head': {
    focus: 'large-scale delivery, strategy, financials',
    questions: [
      'What is the size of delivery you have managed (teams, revenue)?',
      'Have you handled multiple accounts or programs?', 'What is your experience in P&L management?',
      'How do you ensure delivery excellence across projects?', 'Have you driven digital transformation or large programs?',
      'How do you manage client relationships at leadership level?', 'How do you handle escalations and crisis situations?',
      'What governance models have you implemented?', 'What business growth or revenue impact have you driven?',
      'How do you align delivery with business strategy?',
    ],
  },
};

const ROLE_ALIASES = {
  'Senior Team Lead': ['senior team lead', 'team lead', 'stl', 'lead'],
  'Project Manager': ['project manager', 'pm', 'project mgr'],
  'Technical Manager': ['technical manager', 'tech manager', 'tech mgr', 'tm'],
  'Senior HR': ['senior hr', 'hr', 'hr manager', 'hr lead', 'human resources'],
  'Delivery Head': ['delivery head', 'dh', 'delivery manager', 'head of delivery'],
};

function matchRole(userRole) {
  if (!userRole) return null;
  const lower = userRole.toLowerCase().trim();
  for (const [canonical, aliases] of Object.entries(ROLE_ALIASES)) {
    for (const alias of aliases) {
      if (lower.includes(alias) || alias.includes(lower)) return canonical;
    }
  }
  let bestScore = 0, bestRole = null;
  for (const [canonical, aliases] of Object.entries(ROLE_ALIASES)) {
    for (const alias of aliases) {
      const score = simpleSimilarity(lower, alias);
      if (score > bestScore) { bestScore = score; bestRole = canonical; }
    }
  }
  return bestScore >= 60 ? bestRole : null;
}

function simpleSimilarity(a, b) {
  if (a === b) return 100;
  const longer = a.length > b.length ? a : b, shorter = a.length > b.length ? b : a;
  if (!longer.length) return 100;
  let m = 0; for (let i = 0; i < shorter.length; i++) { if (longer.includes(shorter[i])) m++; }
  return Math.round((m / longer.length) * 100);
}

// ─── Template Suggestion Engine ───
function suggestTemplate(cvData) {
  const role = (cvData.profile.current_role || '').toLowerCase();
  const exp = parseInt(cvData.identity.total_years_experience) || 0;
  if (role.includes('director') || role.includes('head') || role.includes('vp') || role.includes('delivery head') || exp > 20) return 'executive';
  if (role.includes('manager') || role.includes('lead') || exp > 10) return 'postcard';
  return 'simple';
}

// ─── Validation ───
function validateCvData(cvData) {
  const errors = [];
  if (!cvData.identity.full_name.trim()) errors.push('Full name is required');
  if (!cvData.identity.portal_id.trim()) errors.push('Portal ID is required');
  if (!cvData.identity.total_years_experience.trim()) errors.push('Years of experience is required');
  else if (isNaN(parseInt(cvData.identity.total_years_experience)) || parseInt(cvData.identity.total_years_experience) < 0)
    errors.push('Years of experience must be a positive number');
  if (!cvData.profile.current_role.trim()) errors.push('Current role is required');
  if (!cvData.profile.current_organization.trim()) errors.push('Current organization is required');
  if (!cvData.summary.profile_summary.trim()) errors.push('Professional summary is required');
  return errors;
}

// ─── Phases ───
const PHASE_IDENTITY = 1, PHASE_SUMMARY = 2, PHASE_PROFILE = 3, PHASE_DOMAIN = 4;
const PHASE_DEEP_DIVE = 5, PHASE_TEMPLATE = 6, PHASE_REVIEW = 7, PHASE_EXPORT = 8;

const PHASE_NAMES = {
  1: 'Identity & Profile', 2: 'Professional Summary', 3: 'Basic Profile',
  4: 'Domain & Expertise', 5: 'Role-Specific Deep Dive', 6: 'Template Selection',
  7: 'Review & Edit', 8: 'Export',
};

const DEFAULT_DEEP_DIVE = [
  'Describe your key responsibilities in your current role.',
  'What are your most significant achievements?',
  'What tools or technologies do you work with regularly?',
  'How do you contribute to team or organizational goals?',
  'What metrics or outcomes best represent your impact?',
];

function getPhaseQuestions(phase, cvData, lang = 'en') {
  if (phase === PHASE_IDENTITY) return t(lang, 'identity');
  if (phase === PHASE_SUMMARY) return t(lang, 'summary');
  if (phase === PHASE_PROFILE) return t(lang, 'profile');
  if (phase === PHASE_DOMAIN) return t(lang, 'domain');
  if (phase === PHASE_DEEP_DIVE) {
    const matched = matchRole(cvData.profile.current_role);
    return (matched && ROLE_QUESTIONS[matched]) ? ROLE_QUESTIONS[matched].questions : DEFAULT_DEEP_DIVE;
  }
  return [];
}

// ─── Sessions ───
const sessions = {};

function createSession(language = 'en', channel = 'web') {
  const sessionId = 'sess_' + Math.random().toString(36).substring(2, 11) + Date.now().toString(36);
  sessions[sessionId] = {
    session_id: sessionId, current_phase: PHASE_IDENTITY, state: 'conversing',
    current_question_index: 0, language, channel,
    cv_data: {
      identity: { full_name: '', portal_id: '', total_years_experience: '' },
      summary: { profile_summary: '', target_roles: '' },
      profile: { current_role: '', current_organization: '', current_location: '' },
      domain: { industries_domains: '', core_expertise: '', key_skills: '' },
      deep_dive: { role_title: '', focus: '', answers: {} },
      template: '', language,
    },
    messages: [],
  };
  return sessions[sessionId];
}

// ─── Parse Answers ───
function parseAnswer(state, text) {
  const phase = state.current_phase, idx = state.current_question_index, cv = state.cv_data;

  if (phase === PHASE_IDENTITY) {
    if (idx === 0) cv.identity.full_name = text.trim();
    else if (idx === 1) cv.identity.portal_id = text.trim();
    else if (idx === 2) cv.identity.total_years_experience = text.trim();
  } else if (phase === PHASE_SUMMARY) {
    if (idx === 0) cv.summary.profile_summary = text.trim();
    else if (idx === 1) cv.summary.target_roles = text.trim();
  } else if (phase === PHASE_PROFILE) {
    if (idx === 0) {
      cv.profile.current_role = text.trim();
      const matched = matchRole(text.trim());
      if (matched) { cv.deep_dive.role_title = matched; cv.deep_dive.focus = ROLE_QUESTIONS[matched].focus; }
    } else if (idx === 1) cv.profile.current_organization = text.trim();
    else if (idx === 2) cv.profile.current_location = text.trim();
  } else if (phase === PHASE_DOMAIN) {
    if (idx === 0) cv.domain.industries_domains = text.trim();
    else if (idx === 1) cv.domain.core_expertise = text.trim();
    else if (idx === 2) cv.domain.key_skills = text.trim();
  } else if (phase === PHASE_DEEP_DIVE) {
    const qs = getPhaseQuestions(PHASE_DEEP_DIVE, cv);
    if (idx < qs.length) cv.deep_dive.answers[`q${idx + 1}`] = text.trim();
  } else if (phase === PHASE_TEMPLATE) {
    const lower = text.toLowerCase().trim();
    if (lower.includes('post') || lower.includes('card')) cv.template = 'postcard';
    else if (lower.includes('executive')) cv.template = 'executive';
    else cv.template = 'simple';
  } else if (phase === PHASE_REVIEW) {
    // "generate" or "go ahead" or "yes" → proceed to export
    const lower = text.toLowerCase().trim();
    if (lower.includes('generate') || lower.includes('go ahead') || lower.includes('yes') || lower.includes('proceed') || lower.includes('ok')) {
      // proceed — will be handled in processUserMessage
    }
    // anything else treated as edit instruction (handled via /edit endpoint)
  } else if (phase === PHASE_EXPORT) {
    state.export_format = text.toLowerCase().trim();
    state.state = 'complete';
  }
}

// ─── Phase Advancement (FIXED) ───
function advancePhase(state) {
  const phase = state.current_phase;
  if (phase >= PHASE_IDENTITY && phase < PHASE_DEEP_DIVE) {
    state.current_phase += 1;
    state.current_question_index = 0;
  } else if (phase === PHASE_DEEP_DIVE) {
    state.current_phase = PHASE_TEMPLATE;
    state.current_question_index = 0;
    // Auto-suggest template if not set
    if (!state.cv_data.template) {
      state.cv_data.template = suggestTemplate(state.cv_data);
    }
  } else if (phase === PHASE_TEMPLATE) {
    state.current_phase = PHASE_REVIEW;
    state.current_question_index = 0;
  } else if (phase === PHASE_REVIEW) {
    state.current_phase = PHASE_EXPORT;
    state.current_question_index = 0;
  } else if (phase === PHASE_EXPORT) {
    state.state = 'complete';
  }
}

function getCurrentPrompt(state) {
  const phase = state.current_phase, lang = state.language;

  // Phases with question lists (1–5)
  if (phase >= PHASE_IDENTITY && phase <= PHASE_DEEP_DIVE) {
    const questions = getPhaseQuestions(phase, state.cv_data, lang);
    if (questions.length > 0 && state.current_question_index < questions.length) {
      return questions[state.current_question_index];
    }
    return t(lang, 'template_msg');
  }

  // Template phase
  if (phase === PHASE_TEMPLATE) {
    const suggested = suggestTemplate(state.cv_data);
    const names = { simple: 'Simple', postcard: 'Post Card', executive: 'Executive' };
    const msg = t(lang, 'template_msg');
    return msg + `\n\nBased on your role, I'd suggest the **${names[suggested] || 'Simple'}** layout.`;
  }

  // Review phase
  if (phase === PHASE_REVIEW) {
    const errors = validateCvData(state.cv_data);
    let msg = t(lang, 'review_msg');
    if (errors.length > 0) {
      msg += '\n\n⚠️ **Missing fields:**\n' + errors.map(e => `- ${e}`).join('\n');
    }
    return msg;
  }

  // Export phase
  if (phase === PHASE_EXPORT) {
    return t(lang, 'export_msg');
  }

  return 'Let\'s continue building your CV.';
}

// ─── Process User Message (FIXED) ───
function processUserMessage(state, userText) {
  state.messages.push({ role: 'user', content: userText, phase: state.current_phase });
  parseAnswer(state, userText);

  const phase = state.current_phase;

  // Question-list phases (1–5): advance per question
  if (phase >= PHASE_IDENTITY && phase <= PHASE_DEEP_DIVE) {
    state.current_question_index += 1;
    const questions = getPhaseQuestions(phase, state.cv_data, state.language);
    if (state.current_question_index >= questions.length) {
      advancePhase(state);
    }
  }
  // Single-action phases (6–8): advance on any input
  else if (phase === PHASE_TEMPLATE) {
    advancePhase(state); // template choice parsed → move to review
  }
  else if (phase === PHASE_REVIEW) {
    const lower = userText.toLowerCase().trim();
    if (lower.includes('generate') || lower.includes('go ahead') || lower.includes('yes') || lower.includes('proceed') || lower.includes('ok')) {
      advancePhase(state); // review done → move to export
    }
    // else stay in review for edits
  }
  else if (phase === PHASE_EXPORT) {
    // format parsed → complete
    state.state = 'complete';
  }

  const response = getCurrentPrompt(state);
  state.messages.push({ role: 'assistant', content: response, phase: state.current_phase });
  return response;
}

// ─── CV Summary ───
function getCvSummary(state) {
  const cv = state.cv_data;
  const deepDiveAnswers = {};
  const questions = getPhaseQuestions(PHASE_DEEP_DIVE, cv, state.language);
  for (const [k, v] of Object.entries(cv.deep_dive.answers)) {
    const idx = parseInt(k.replace('q', '')) - 1;
    deepDiveAnswers[idx < questions.length ? questions[idx] : k] = v;
  }
  return {
    identity: { ...cv.identity }, summary: { ...cv.summary }, profile: { ...cv.profile },
    domain: { ...cv.domain },
    deep_dive: { role_title: cv.deep_dive.role_title, focus: cv.deep_dive.focus, answers: deepDiveAnswers },
    template: cv.template, language: cv.language,
    validation_errors: validateCvData(cv),
    suggested_template: suggestTemplate(cv),
  };
}

// ─── Apply Edit ───
function applyEdit(state, field, value) {
  const parts = field.split('.');
  let obj = state.cv_data;
  for (let i = 0; i < parts.length - 1; i++) { if (!obj[parts[i]]) return `Field '${field}' not found.`; obj = obj[parts[i]]; }
  obj[parts[parts.length - 1]] = value;
  return `Updated ${field} to: ${value}`;
}

// ─── PDF Generation ───
function generatePDF(cv) {
  const PDFDocument = require('pdfkit');
  const safeName = cv.identity.full_name.replace(/\s+/g, '_') || 'cv';
  const filePath = path.join(OUTPUT_DIR, `${safeName}.pdf`);
  const doc = new PDFDocument({ size: 'A4', margin: 50 });
  const stream = fs.createWriteStream(filePath);
  doc.pipe(stream);

  const primary = '#A3238E', secondary = '#004B87', textColor = '#333333';

  doc.rect(0, 0, doc.page.width, 8).fill(primary);

  if (cv.identity.full_name) doc.fontSize(22).fillColor(secondary).font('Helvetica-Bold').text(cv.identity.full_name, 50, 50);
  const roleParts = [cv.profile.current_role, cv.profile.current_organization, cv.profile.current_location].filter(Boolean);
  if (roleParts.length) doc.fontSize(12).fillColor(primary).font('Helvetica-Bold').text(roleParts.join(' | '), 50, undefined, { lineGap: 4 });
  if (cv.identity.total_years_experience) doc.fontSize(10).fillColor(textColor).font('Helvetica').text(`Total Experience: ${cv.identity.total_years_experience} years`);
  if (cv.identity.portal_id) doc.fontSize(10).fillColor(textColor).font('Helvetica').text(`Portal ID: ${cv.identity.portal_id}`);
  doc.moveDown(0.5);
  doc.moveTo(50, doc.y).lineTo(doc.page.width - 50, doc.y).strokeColor(primary).lineWidth(1).stroke();
  doc.moveDown(0.5);

  function addSection(title, content) {
    if (!content) return;
    doc.moveDown(0.5);
    doc.fontSize(13).fillColor(primary).font('Helvetica-Bold').text(title);
    doc.moveDown(0.2);
    doc.moveTo(50, doc.y).lineTo(doc.page.width - 50, doc.y).strokeColor(primary).lineWidth(0.5).stroke();
    doc.moveDown(0.3);
    doc.fontSize(10).fillColor(textColor).font('Helvetica').text(content, { lineGap: 3 });
  }

  if (cv.summary.profile_summary) addSection('Professional Summary', cv.summary.profile_summary);
  if (cv.summary.target_roles) addSection('Target Roles', cv.summary.target_roles);
  const domainParts = [];
  if (cv.domain.industries_domains) domainParts.push(`Industries/Domains: ${cv.domain.industries_domains}`);
  if (cv.domain.core_expertise) domainParts.push(`Core Expertise: ${cv.domain.core_expertise}`);
  if (cv.domain.key_skills) domainParts.push(`Key Skills: ${cv.domain.key_skills}`);
  if (domainParts.length) addSection('Domain & Expertise', domainParts.join('\n'));

  const dd = cv.deep_dive;
  if (Object.keys(dd.answers).length > 0) {
    let title = dd.role_title ? `${dd.role_title} Deep Dive` : 'Role-Specific Details';
    if (dd.focus) title += ` — ${dd.focus}`;
    doc.moveDown(0.5);
    doc.fontSize(13).fillColor(primary).font('Helvetica-Bold').text(title);
    doc.moveDown(0.2);
    doc.moveTo(50, doc.y).lineTo(doc.page.width - 50, doc.y).strokeColor(primary).lineWidth(0.5).stroke();
    doc.moveDown(0.3);
    const questions = getPhaseQuestions(PHASE_DEEP_DIVE, cv);
    for (const [k, v] of Object.entries(dd.answers)) {
      const idx = parseInt(k.replace('q', '')) - 1;
      doc.fontSize(10).fillColor(textColor).font('Helvetica-Bold').text(idx < questions.length ? questions[idx] : `Q${idx + 1}`);
      doc.fontSize(10).fillColor(textColor).font('Helvetica').text(v, { lineGap: 2 });
      doc.moveDown(0.3);
    }
  }

  doc.moveDown(2);
  doc.moveTo(50, doc.y).lineTo(doc.page.width - 50, doc.y).strokeColor('#999999').lineWidth(0.5).stroke();
  doc.moveDown(0.3);
  doc.fontSize(7).fillColor('#999999').font('Helvetica').text(NTT_BRAND.footer_text, { align: 'center' });
  doc.rect(0, doc.page.height - 20, doc.page.width, 3).fill(secondary);
  doc.end();

  return new Promise(resolve => stream.on('finish', () => resolve(filePath)));
}

// ─── DOCX Generation ───
async function generateDOCX(cv) {
  const { Document, Packer, Paragraph, TextRun, AlignmentType, BorderStyle } = require('docx');
  const safeName = cv.identity.full_name.replace(/\s+/g, '_') || 'cv';
  const filePath = path.join(OUTPUT_DIR, `${safeName}.docx`);
  const children = [];

  if (cv.identity.full_name) children.push(new Paragraph({ children: [new TextRun({ text: cv.identity.full_name, bold: true, size: 44, color: '004B87' })] }));
  const roleParts = [cv.profile.current_role, cv.profile.current_organization, cv.profile.current_location].filter(Boolean);
  if (roleParts.length) children.push(new Paragraph({ children: [new TextRun({ text: roleParts.join(' | '), bold: true, size: 24, color: 'A3238E' })] }));
  if (cv.identity.total_years_experience) children.push(new Paragraph({ children: [new TextRun({ text: `Total Experience: ${cv.identity.total_years_experience} years`, size: 20 })] }));
  if (cv.identity.portal_id) children.push(new Paragraph({ children: [new TextRun({ text: `Portal ID: ${cv.identity.portal_id}`, size: 20 })] }));
  children.push(new Paragraph({ children: [], border: { bottom: { style: BorderStyle.SINGLE, size: 3, color: 'A3238E' } } }));

  function addSection(title, content) {
    if (!content) return;
    children.push(new Paragraph({ children: [new TextRun({ text: title, bold: true, size: 26, color: 'A3238E' })], spacing: { before: 200 } }));
    children.push(new Paragraph({ children: [], border: { bottom: { style: BorderStyle.SINGLE, size: 1, color: 'A3238E' } } }));
    children.push(new Paragraph({ children: [new TextRun({ text: content, size: 20 })], spacing: { before: 60 } }));
  }

  if (cv.summary.profile_summary) addSection('Professional Summary', cv.summary.profile_summary);
  if (cv.summary.target_roles) addSection('Target Roles', cv.summary.target_roles);
  const dl = [];
  if (cv.domain.industries_domains) dl.push(`Industries/Domains: ${cv.domain.industries_domains}`);
  if (cv.domain.core_expertise) dl.push(`Core Expertise: ${cv.domain.core_expertise}`);
  if (cv.domain.key_skills) dl.push(`Key Skills: ${cv.domain.key_skills}`);
  if (dl.length) addSection('Domain & Expertise', dl.join('\n'));

  const dd = cv.deep_dive;
  if (Object.keys(dd.answers).length > 0) {
    let title = dd.role_title ? `${dd.role_title} Deep Dive` : 'Role-Specific Details';
    if (dd.focus) title += ` — ${dd.focus}`;
    children.push(new Paragraph({ children: [new TextRun({ text: title, bold: true, size: 26, color: 'A3238E' })], spacing: { before: 200 } }));
    children.push(new Paragraph({ children: [], border: { bottom: { style: BorderStyle.SINGLE, size: 1, color: 'A3238E' } } }));
    const questions = getPhaseQuestions(PHASE_DEEP_DIVE, cv);
    for (const [k, v] of Object.entries(dd.answers)) {
      const idx = parseInt(k.replace('q', '')) - 1;
      children.push(new Paragraph({ children: [new TextRun({ text: idx < questions.length ? questions[idx] : `Q${idx + 1}`, bold: true, size: 20 })], spacing: { before: 100 } }));
      children.push(new Paragraph({ children: [new TextRun({ text: v, size: 20 })] }));
    }
  }

  children.push(new Paragraph({ children: [], border: { bottom: { style: BorderStyle.SINGLE, size: 1, color: '999999' } }, spacing: { before: 400 } }));
  children.push(new Paragraph({ children: [new TextRun({ text: NTT_BRAND.footer_text, size: 14, color: '999999' })], alignment: AlignmentType.CENTER }));

  const buffer = await Packer.toBuffer(new Document({ sections: [{ properties: {}, children }] }));
  fs.writeFileSync(filePath, buffer);
  return filePath;
}

// ═══════════════════════════════════════════════
// API Routes
// ═══════════════════════════════════════════════

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.post('/api/session', (req, res) => {
  const language = req.body.language || 'en';
  const channel = req.body.channel || 'web'; // web, mobile, whatsapp, ivr
  const state = createSession(language, channel);
  res.json({
    session_id: state.session_id, opening_message: t(language, 'opening'),
    phase: state.current_phase, phase_name: PHASE_NAMES[state.current_phase], channel,
  });
});

app.get('/api/session/:sid', (req, res) => {
  const state = sessions[req.params.sid];
  if (!state) return res.status(404).json({ detail: 'Session not found' });
  res.json({
    session_id: state.session_id, phase: state.current_phase,
    phase_name: PHASE_NAMES[state.current_phase], state: state.state,
    current_question_index: state.current_question_index,
    cv_summary: getCvSummary(state), language: state.language, channel: state.channel,
  });
});

app.delete('/api/session/:sid', (req, res) => { delete sessions[req.params.sid]; res.json({ status: 'deleted' }); });

app.post('/api/session/:sid/message', (req, res) => {
  const state = sessions[req.params.sid];
  if (!state) return res.status(404).json({ detail: 'Session not found' });
  const userText = (req.body.content || '').trim();
  if (!userText) return res.status(400).json({ detail: 'Empty message' });
  const response = processUserMessage(state, userText);
  res.json({
    response, phase: state.current_phase, phase_name: PHASE_NAMES[state.current_phase],
    state: state.state, cv_summary: getCvSummary(state),
  });
});

// ─── STT Endpoint: accept base64 audio, return transcribed text ───
app.post('/api/stt', async (req, res) => {
  const { audio_base64, language = 'en' } = req.body;
  if (!audio_base64) return res.status(400).json({ detail: 'No audio_base64 provided' });

  // If OpenAI Whisper is configured, use it
  if (OPENAI_API_KEY) {
    try {
      const openai = require('openai');
      const client = new openai.default({ apiKey: OPENAI_API_KEY });
      const buffer = Buffer.from(audio_base64, 'base64');
      const tmpPath = path.join(OUTPUT_DIR, `stt_${Date.now()}.webm`);
      fs.writeFileSync(tmpPath, buffer);
      const transcription = await client.audio.transcriptions.create({
        file: fs.createReadStream(tmpPath), model: 'whisper-1', language,
      });
      fs.unlinkSync(tmpPath);
      return res.json({ text: transcription.text });
    } catch (err) {
      console.error('STT Whisper error:', err.message);
      return res.status(500).json({ detail: 'STT failed', text: '' });
    }
  }

  // Fallback: return empty — frontend uses browser Web Speech API
  res.json({ text: '', note: 'Set OPENAI_API_KEY for server-side STT. Use browser Web Speech API for client-side.' });
});

// ─── Template Suggestion ───
app.get('/api/session/:sid/suggest-template', (req, res) => {
  const state = sessions[req.params.sid];
  if (!state) return res.status(404).json({ detail: 'Session not found' });
  const suggested = suggestTemplate(state.cv_data);
  const names = { simple: 'Simple', postcard: 'Post Card', executive: 'Executive' };
  res.json({ suggested, name: names[suggested], reason: getTemplateReason(state.cv_data, suggested) });
});

function getTemplateReason(cvData, template) {
  const exp = parseInt(cvData.identity.total_years_experience) || 0;
  const role = (cvData.profile.current_role || '').toLowerCase();
  if (template === 'executive') return 'Senior leadership role with extensive experience — executive layout highlights strategic impact.';
  if (template === 'postcard') return 'Management/lead role — post card layout balances visual appeal with professional depth.';
  return 'Technical or early-career role — simple layout keeps focus on skills and experience.';
}

app.post('/api/session/:sid/template', (req, res) => {
  const state = sessions[req.params.sid];
  if (!state) return res.status(404).json({ detail: 'Session not found' });
  const id = req.body.template || 'simple';
  if (!['simple', 'postcard', 'executive'].includes(id)) return res.status(400).json({ detail: `Unknown template: ${id}` });
  state.cv_data.template = id;
  res.json({ template: id });
});

app.post('/api/session/:sid/edit', (req, res) => {
  const state = sessions[req.params.sid];
  if (!state) return res.status(404).json({ detail: 'Session not found' });
  const result = applyEdit(state, req.body.field, req.body.value);
  res.json({ result, cv_summary: getCvSummary(state) });
});

// ─── Validation ───
app.get('/api/session/:sid/validate', (req, res) => {
  const state = sessions[req.params.sid];
  if (!state) return res.status(404).json({ detail: 'Session not found' });
  const errors = validateCvData(state.cv_data);
  res.json({ valid: errors.length === 0, errors });
});

app.post('/api/session/:sid/export', async (req, res) => {
  const state = sessions[req.params.sid];
  if (!state) return res.status(404).json({ detail: 'Session not found' });
  const cv = state.cv_data, fmt = (req.body.format || 'pdf').toLowerCase();
  if (fmt === 'json') return res.json(getCvSummary(state));
  try {
    let filePath, ext;
    if (fmt === 'pdf') { filePath = await generatePDF(cv); ext = '.pdf'; }
    else if (fmt === 'docx') { filePath = await generateDOCX(cv); ext = '.docx'; }
    else return res.status(400).json({ detail: `Unsupported format: ${fmt}` });
    const safeName = cv.identity.full_name.replace(/\s+/g, '_') || 'cv';
    return res.download(filePath, `${safeName}${ext}`);
  } catch (err) { console.error('Export error:', err); return res.status(500).json({ detail: `Generation failed: ${err.message}` }); }
});

app.get('/api/session/:sid/preview', (req, res) => {
  const state = sessions[req.params.sid];
  if (!state) return res.status(404).json({ detail: 'Session not found' });
  res.json(getCvSummary(state));
});

app.get('/api/templates', (req, res) => res.json([
  { id: 'simple', name: 'Simple', description: 'Clean, professional layout. Best for technical roles.' },
  { id: 'postcard', name: 'Post Card', description: 'Centered layout with side accent. Modern and visual.' },
  { id: 'executive', name: 'Executive', description: 'Bold headings, double bars. Best for senior/leadership roles.' },
]));

app.get('/api/languages', (req, res) => res.json([
  { code: 'en', name: 'English' }, { code: 'es', name: 'Español' },
  { code: 'pt', name: 'Português' }, { code: 'ja', name: '日本語' },
]));

const logoPath = path.join(__dirname, 'assets', 'ntt_data_logo.png');
app.get('/api/logo', (req, res) => {
  if (fs.existsSync(logoPath)) return res.sendFile(logoPath);
  res.status(404).json({ detail: 'Logo not found' });
});

// ─── Messaging Platform Webhooks (WhatsApp, Teams, Slack) ───
app.post('/api/webhook/:platform', async (req, res) => {
  const platform = req.params.platform; // whatsapp, teams, slack
  const { session_id, message, phone, language } = req.body;

  let state = sessions[session_id];
  if (!state) {
    state = createSession(language || 'en', platform);
    // Return opening + first question
    const opening = t(state.language, 'opening');
    state.messages.push({ role: 'assistant', content: opening, phase: state.current_phase });
    return res.json({
      session_id: state.session_id, response: opening + '\n\n' + getCurrentPrompt(state),
      phase: state.current_phase, phase_name: PHASE_NAMES[state.current_phase],
    });
  }

  const response = processUserMessage(state, message || '');
  res.json({
    session_id: state.session_id, response,
    phase: state.current_phase, phase_name: PHASE_NAMES[state.current_phase],
    state: state.state,
  });
});

// SPA fallback
app.get('*', (req, res) => {
  const indexPath = path.join(frontendDist, 'index.html');
  if (fs.existsSync(indexPath)) return res.sendFile(indexPath);
  res.status(404).json({ detail: 'Frontend not built. Run: cd frontend && npm run build' });
});

app.listen(PORT, () => {
  console.log(`\n  NTT DATA CV Builder API running at http://localhost:${PORT}`);
  console.log('  Features: STT, multilingual, template suggestion, validation, messaging webhooks');
  console.log('  Frontend dev: cd frontend && npm run dev\n');
});