"""Conversation engine — state machine for guided CV creation."""

from __future__ import annotations

import uuid
from typing import Optional

from config import (
    PHASE_IDENTITY, PHASE_SUMMARY, PHASE_PROFILE, PHASE_DOMAIN,
    PHASE_DEEP_DIVE, PHASE_TEMPLATE, PHASE_REVIEW, PHASE_EXPORT,
    PHASE_NAMES, STATE_CONVERSING, STATE_REVIEW, STATE_EXPORT, STATE_COMPLETE,
    ROLE_QUESTIONS, ROLE_ALIASES, FUZZY_MATCH_THRESHOLD,
    TEMPLATE_SIMPLE, TEMPLATE_POSTCARD, TEMPLATE_EXECUTIVE, TEMPLATE_NAMES,
    DEFAULT_LANGUAGE,
)
from core.models import (
    ConversationState, ChatMessage, CVData, IdentityProfile,
    ProfessionalSummary, BasicProfile, DomainExpertise, RoleDeepDive,
)
from utils.role_matcher import match_role


# ---------- Phase question sequences ----------

IDENTITY_QUESTIONS = [
    "What is your full name as it should appear on the CV?",
    "What is your portal ID?",
    "What are your total years of experience?",
]

SUMMARY_QUESTIONS = [
    "How would you describe your professional profile in 2 to 3 lines?",
    "What kinds of roles are you targeting?",
]

PROFILE_QUESTIONS = [
    "What is your current role/title?",
    "What is your current organization?",
    "What is your current location?",
]

DOMAIN_QUESTIONS = [
    "Which industries or domains have you worked in?",
    "What are your core areas of expertise?",
    "What are your key skills (technical or functional)?",
]

OPENING_MESSAGE = (
    "Hi! I can help you build your NTT DATA CV. Shall we start? "
    "I'll guide you through each section step by step."
)


def get_phase_questions(phase: int, cv_data: CVData) -> list[str]:
    """Return the question list for the given phase."""
    if phase == PHASE_IDENTITY:
        return IDENTITY_QUESTIONS
    if phase == PHASE_SUMMARY:
        return SUMMARY_QUESTIONS
    if phase == PHASE_PROFILE:
        return PROFILE_QUESTIONS
    if phase == PHASE_DOMAIN:
        return DOMAIN_QUESTIONS
    if phase == PHASE_DEEP_DIVE:
        role = cv_data.profile.current_role
        matched = match_role(role)
        if matched and matched in ROLE_QUESTIONS:
            return ROLE_QUESTIONS[matched]["questions"]
        # Fallback: flatten all role questions
        return _default_deep_dive_questions()
    return []


def _default_deep_dive_questions() -> list[str]:
    """Fallback questions when role doesn't match any template."""
    return [
        "Describe your key responsibilities in your current role.",
        "What are your most significant achievements?",
        "What tools or technologies do you work with regularly?",
        "How do you contribute to team or organizational goals?",
        "What metrics or outcomes best represent your impact?",
    ]


def get_current_prompt(state: ConversationState) -> str:
    """Return the next prompt the bot should show to the user."""
    phase = state.current_phase
    idx = state.current_question_index
    questions = get_phase_questions(phase, state.cv_data)

    if not questions:
        return _transition_message(state)

    if idx < len(questions):
        return questions[idx]

    # All questions in this phase answered — move to next phase
    _advance_phase(state)
    return get_current_prompt(state)


def _transition_message(state: ConversationState) -> str:
    """Generate a transition message between phases."""
    phase = state.current_phase

    if phase == PHASE_TEMPLATE:
        return (
            "Great! We've covered all the content. Now let's pick a template.\n"
            "Would you like a **Simple**, **Post Card**, or **Executive** layout?"
        )
    if phase == PHASE_REVIEW:
        return (
            "Here's a summary of your CV data. Would you like to review and edit anything, "
            "or shall I generate the document?"
        )
    if phase == PHASE_EXPORT:
        return (
            "I'll generate your CV. Which format do you prefer — **PDF**, **DOCX**, or **JSON**?"
        )
    return "Let's continue building your CV."


def _advance_phase(state: ConversationState) -> None:
    """Move to the next conversation phase."""
    if state.current_phase < PHASE_DEEP_DIVE:
        state.current_phase += 1
        state.current_question_index = 0
    elif state.current_phase == PHASE_DEEP_DIVE:
        state.current_phase = PHASE_TEMPLATE
        state.current_question_index = 0
        state.state = STATE_CONVERSING


def create_session(language: str = DEFAULT_LANGUAGE) -> ConversationState:
    """Create a new conversation session."""
    return ConversationState(
        session_id=str(uuid.uuid4()),
        current_phase=PHASE_IDENTITY,
        state=STATE_CONVERSING,
        cv_data=CVData(language=language),
        messages=[],
        current_question_index=0,
        language=language,
    )


def process_user_message(state: ConversationState, user_text: str) -> str:
    """Process a user message, update state, and return the bot response.

    This is the core of the conversation engine:
    1. Store the user message
    2. Parse the answer into the CV data model for the current phase/question
    3. Advance the question index or phase
    4. Return the next prompt
    """
    # Store user message
    state.messages.append(ChatMessage(
        role="user", content=user_text, phase=state.current_phase,
    ))

    # Parse answer into CV data
    _parse_answer(state, user_text)

    # Advance
    state.current_question_index += 1
    questions = get_phase_questions(state.current_phase, state.cv_data)

    if state.current_question_index >= len(questions):
        _advance_phase(state)

    # Get next prompt
    response = get_current_prompt(state)

    # Store assistant message
    state.messages.append(ChatMessage(
        role="assistant", content=response, phase=state.current_phase,
    ))

    return response


def _parse_answer(state: ConversationState, text: str) -> None:
    """Parse user answer into the correct CV data field based on current phase & index."""
    phase = state.current_phase
    idx = state.current_question_index

    if phase == PHASE_IDENTITY:
        if idx == 0:
            state.cv_data.identity.full_name = text.strip()
        elif idx == 1:
            state.cv_data.identity.portal_id = text.strip()
        elif idx == 2:
            state.cv_data.identity.total_years_experience = text.strip()

    elif phase == PHASE_SUMMARY:
        if idx == 0:
            state.cv_data.summary.profile_summary = text.strip()
        elif idx == 1:
            state.cv_data.summary.target_roles = text.strip()

    elif phase == PHASE_PROFILE:
        if idx == 0:
            state.cv_data.profile.current_role = text.strip()
            # Resolve role for deep dive
            matched = match_role(text.strip())
            if matched:
                state.cv_data.deep_dive.role_title = matched
                state.cv_data.deep_dive.focus = ROLE_QUESTIONS[matched]["focus"]
        elif idx == 1:
            state.cv_data.profile.current_organization = text.strip()
        elif idx == 2:
            state.cv_data.profile.current_location = text.strip()

    elif phase == PHASE_DOMAIN:
        if idx == 0:
            state.cv_data.domain.industries_domains = text.strip()
        elif idx == 1:
            state.cv_data.domain.core_expertise = text.strip()
        elif idx == 2:
            state.cv_data.domain.key_skills = text.strip()

    elif phase == PHASE_DEEP_DIVE:
        questions = get_phase_questions(PHASE_DEEP_DIVE, state.cv_data)
        if idx < len(questions):
            q_key = f"q{idx + 1}"
            state.cv_data.deep_dive.answers[q_key] = text.strip()

    elif phase == PHASE_TEMPLATE:
        _parse_template_choice(state, text)

    elif phase == PHASE_EXPORT:
        _parse_export_choice(state, text)


def _parse_template_choice(state: ConversationState, text: str) -> None:
    """Parse the user's template choice."""
    lower = text.lower().strip()
    if "post" in lower or "card" in lower:
        state.cv_data.template = TEMPLATE_POSTCARD
    elif "executive" in lower:
        state.cv_data.template = TEMPLATE_EXECUTIVE
    else:
        state.cv_data.template = TEMPLATE_SIMPLE


def _parse_export_choice(state: ConversationState, text: str) -> None:
    """Parse the user's export format choice."""
    state.state = STATE_COMPLETE


def apply_edit(state: ConversationState, field: str, value: str) -> str:
    """Allow the user to edit a specific CV field during review phase."""
    parts = field.split(".")
    obj = state.cv_data
    for part in parts[:-1]:
        obj = getattr(obj, part, None)
        if obj is None:
            return f"Field '{field}' not found."
    setattr(obj, parts[-1], value)
    return f"Updated {field} to: {value}"


def get_cv_summary(state: ConversationState) -> dict:
    """Return a serializable summary of all collected CV data for review."""
    cv = state.cv_data
    deep_dive_answers = {}
    for k, v in cv.deep_dive.answers.items():
        idx = int(k.replace("q", "")) - 1
        questions = get_phase_questions(PHASE_DEEP_DIVE, cv)
        label = questions[idx] if idx < len(questions) else k
        deep_dive_answers[label] = v

    return {
        "identity": cv.identity.model_dump(),
        "summary": cv.summary.model_dump(),
        "profile": cv.profile.model_dump(),
        "domain": cv.domain.model_dump(),
        "deep_dive": {
            "role_title": cv.deep_dive.role_title,
            "focus": cv.deep_dive.focus,
            "answers": deep_dive_answers,
        },
        "template": cv.template,
        "language": cv.language,
    }