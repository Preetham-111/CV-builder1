"""Pydantic models for CV data schema."""

from typing import Optional
from pydantic import BaseModel, Field


class IdentityProfile(BaseModel):
    """Phase 1: Identity & Profile basics."""
    full_name: str = ""
    portal_id: str = ""
    total_years_experience: str = ""


class ProfessionalSummary(BaseModel):
    """Phase 2: Professional summary."""
    profile_summary: str = ""
    target_roles: str = ""


class BasicProfile(BaseModel):
    """Phase 3: Basic profile details."""
    current_role: str = ""
    current_organization: str = ""
    current_location: str = ""


class DomainExpertise(BaseModel):
    """Phase 4: Domain & expertise."""
    industries_domains: str = ""
    core_expertise: str = ""
    key_skills: str = ""


class RoleDeepDive(BaseModel):
    """Phase 5: Role-specific deep dive answers."""
    role_title: str = ""
    answers: dict[str, str] = Field(default_factory=dict)
    focus: str = ""


class CVData(BaseModel):
    """Complete CV data model — the canonical schema."""
    identity: IdentityProfile = Field(default_factory=IdentityProfile)
    summary: ProfessionalSummary = Field(default_factory=ProfessionalSummary)
    profile: BasicProfile = Field(default_factory=BasicProfile)
    domain: DomainExpertise = Field(default_factory=DomainExpertise)
    deep_dive: RoleDeepDive = Field(default_factory=RoleDeepDive)
    template: str = "simple"
    language: str = "en"


class ChatMessage(BaseModel):
    """A single chat message."""
    role: str = Field(..., pattern="^(user|assistant|system)$")
    content: str
    phase: int = 1
    timestamp: Optional[str] = None


class ConversationState(BaseModel):
    """Full conversation state for a session."""
    session_id: str = ""
    current_phase: int = 1
    state: str = "conversing"
    cv_data: CVData = Field(default_factory=CVData)
    messages: list[ChatMessage] = Field(default_factory=list)
    current_question_index: int = 0
    language: str = "en"


class TemplateInfo(BaseModel):
    """Info about a CV template."""
    id: str
    name: str
    description: str