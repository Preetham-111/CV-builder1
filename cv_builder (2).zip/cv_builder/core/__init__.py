"""Core package — models and conversation engine."""

from core.models import CVData, ConversationState, ChatMessage, TemplateInfo
from core.conversation import (
    create_session,
    process_user_message,
    get_current_prompt,
    get_cv_summary,
    apply_edit,
    OPENING_MESSAGE,
)