"""PDF CV generator — NTT DATA branded, with 3 template layouts."""

from __future__ import annotations

import io
from pathlib import Path
from typing import Optional

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm, cm
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY, TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    Image, HRFlowable, KeepTogether, PageBreak,
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

from config import NTT_BRAND, NTT_LOGO_PATH, OUTPUT_DIR
from core.models import CVData


# ---------- Colour helpers ----------

def _hex_to_color(hex_str: str) -> colors.Color:
    """Convert #RRGGBB to a reportlab Color."""
    h = hex_str.lstrip("#")
    r, g, b = int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255
    return colors.Color(r, g, b)


PRIMARY = _hex_to_color(NTT_BRAND["primary_color"])
SECONDARY = _hex_to_color(NTT_BRAND["secondary_color"])
ACCENT = _hex_to_color(NTT_BRAND["accent_color"])
LIGHT_BG = _hex_to_color(NTT_BRAND["light_bg"])
TEXT_COLOR = _hex_to_color(NTT_BRAND["text_color"])


# ---------- Style factories ----------

def _build_styles(template: str) -> dict:
    """Build paragraph styles for a given template."""
    base = getSampleStyleSheet()

    styles = {
        "name": ParagraphStyle(
            "CVName", parent=base["Title"],
            fontSize=22, leading=26, textColor=SECONDARY,
            spaceAfter=4, fontName="Helvetica-Bold",
        ),
        "role": ParagraphStyle(
            "CVRole", parent=base["Normal"],
            fontSize=13, leading=16, textColor=PRIMARY,
            spaceAfter=2, fontName="Helvetica-Bold",
        ),
        "section": ParagraphStyle(
            "CVSection", parent=base["Heading2"],
            fontSize=13, leading=16, textColor=PRIMARY,
            spaceBefore=12, spaceAfter=4,
            fontName="Helvetica-Bold",
            borderColor=PRIMARY, borderWidth=1, borderPadding=2,
        ),
        "body": ParagraphStyle(
            "CVBody", parent=base["Normal"],
            fontSize=10, leading=13, textColor=TEXT_COLOR,
            spaceAfter=4, fontName="Helvetica",
        ),
        "body_bold": ParagraphStyle(
            "CVBodyBold", parent=base["Normal"],
            fontSize=10, leading=13, textColor=TEXT_COLOR,
            spaceAfter=4, fontName="Helvetica-Bold",
        ),
        "small": ParagraphStyle(
            "CVSmall", parent=base["Normal"],
            fontSize=8, leading=10, textColor=colors.grey,
            fontName="Helvetica",
        ),
        "footer": ParagraphStyle(
            "CVFooter", parent=base["Normal"],
            fontSize=7, leading=9, textColor=colors.grey,
            alignment=TA_CENTER, fontName="Helvetica",
        ),
    }

    # Template-specific overrides
    if template == "postcard":
        styles["name"].fontSize = 18
        styles["name"].alignment = TA_CENTER
        styles["role"].alignment = TA_CENTER
    elif template == "executive":
        styles["name"].fontSize = 26
        styles["name"].textColor = PRIMARY
        styles["section"].fontSize = 14
        styles["body"].fontSize = 10.5

    return styles


# ---------- Section builders ----------

def _header_block(cv: CVData, styles: dict, template: str) -> list:
    """Build the name/role/contact header."""
    elements = []
    identity = cv.identity
    profile = cv.profile

    # Logo
    if NTT_LOGO_PATH.exists():
        logo = Image(str(NTT_LOGO_PATH), width=120, height=30)
        if template == "postcard":
            logo.hAlign = "CENTER"
        elements.append(logo)
        elements.append(Spacer(1, 6))

    # Name
    if identity.full_name:
        elements.append(Paragraph(identity.full_name, styles["name"]))

    # Role + org
    role_line = " | ".join(filter(None, [
        profile.current_role, profile.current_organization, profile.current_location,
    ]))
    if role_line:
        elements.append(Paragraph(role_line, styles["role"]))

    # Experience
    if identity.total_years_experience:
        elements.append(Paragraph(
            f"Total Experience: {identity.total_years_experience} years",
            styles["body"]
        ))

    elements.append(HRFlowable(width="100%", thickness=1, color=PRIMARY))
    elements.append(Spacer(1, 6))
    return elements


def _section(title: str, content: str, styles: dict) -> list:
    """Build a titled section block."""
    elements = []
    if content:
        elements.append(Paragraph(title, styles["section"]))
        elements.append(Paragraph(content, styles["body"]))
    return elements


def _deep_dive_section(cv: CVData, styles: dict) -> list:
    """Build the role-specific deep dive section."""
    elements = []
    dd = cv.deep_dive
    if not dd.answers:
        return elements

    title = f"{dd.role_title} Deep Dive" if dd.role_title else "Role-Specific Details"
    if dd.focus:
        title += f" — {dd.focus}"
    elements.append(Paragraph(title, styles["section"]))

    for q_key in sorted(dd.answers.keys(), key=lambda x: int(x.replace("q", ""))):
        idx = int(q_key.replace("q", "")) - 1
        from core.conversation import get_phase_questions
        from config import PHASE_DEEP_DIVE
        questions = get_phase_questions(PHASE_DEEP_DIVE, cv)
        label = questions[idx] if idx < len(questions) else f"Q{idx + 1}"

        elements.append(Paragraph(f"<b>{label}</b>", styles["body_bold"]))
        elements.append(Paragraph(dd.answers[q_key], styles["body"]))
        elements.append(Spacer(1, 2))

    return elements


# ---------- Main entry point ----------

def generate_pdf(cv: CVData, output_path: Optional[Path] = None) -> Path:
    """Generate an NTT DATA branded PDF CV.

    Args:
        cv: The CV data model.
        output_path: Optional output path; defaults to output/<name>.pdf.

    Returns:
        Path to the generated PDF file.
    """
    if output_path is None:
        safe_name = cv.identity.full_name.replace(" ", "_") or "cv"
        output_path = OUTPUT_DIR / f"{safe_name}.pdf"

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    styles = _build_styles(cv.template)
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=2*cm, rightMargin=2*cm,
        topMargin=2*cm, bottomMargin=2*cm,
    )

    elements = []

    # Header
    elements.extend(_header_block(cv, styles, cv.template))

    # Professional Summary
    if cv.summary.profile_summary:
        elements.extend(_section("Professional Summary", cv.summary.profile_summary, styles))

    # Target Roles
    if cv.summary.target_roles:
        elements.extend(_section("Target Roles", cv.summary.target_roles, styles))

    # Domain & Expertise
    domain_parts = []
    if cv.domain.industries_domains:
        domain_parts.append(f"<b>Industries/Domains:</b> {cv.domain.industries_domains}")
    if cv.domain.core_expertise:
        domain_parts.append(f"<b>Core Expertise:</b> {cv.domain.core_expertise}")
    if cv.domain.key_skills:
        domain_parts.append(f"<b>Key Skills:</b> {cv.domain.key_skills}")
    if domain_parts:
        elements.extend(_section("Domain & Expertise", "<br/>".join(domain_parts), styles))

    # Deep Dive
    elements.extend(_deep_dive_section(cv, styles))

    # Footer
    elements.append(Spacer(1, 12))
    elements.append(HRFlowable(width="100%", thickness=0.5, color=colors.grey))
    elements.append(Paragraph(NTT_BRAND["footer_text"], styles["footer"]))

    # Template-specific page decorations
    def _on_page(canvas, doc):
        """Page-level decorations."""
        # Magenta top bar
        canvas.setFillColor(PRIMARY)
        canvas.rect(0, A4[1] - 8, A4[0], 8, fill=True, stroke=False)
        # Thin bottom bar
        canvas.setFillColor(SECONDARY)
        canvas.rect(0, 0, A4[0], 3, fill=True, stroke=False)

        if cv.template == "postcard":
            # Side accent stripe
            canvas.setFillColor(ACCENT)
            canvas.rect(0, 0, 6, A4[1], fill=True, stroke=False)
        elif cv.template == "executive":
            # Double top bars
            canvas.setFillColor(SECONDARY)
            canvas.rect(0, A4[1] - 14, A4[0], 6, fill=True, stroke=False)

    doc.build(elements, onFirstPage=_on_page, onLaterPages=_on_page)
    buffer.seek(0)

    with open(output_path, "wb") as f:
        f.write(buffer.read())

    return output_path


def generate_pdf_bytes(cv: CVData) -> bytes:
    """Generate PDF and return as bytes (for API download)."""
    safe_name = cv.identity.full_name.replace(" ", "_") or "cv"
    path = OUTPUT_DIR / f"{safe_name}.pdf"
    generate_pdf(cv, path)
    return path.read_bytes()