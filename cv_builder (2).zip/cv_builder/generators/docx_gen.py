"""DOCX CV generator — NTT DATA branded, with 3 template layouts."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from docx import Document
from docx.shared import Pt, Inches, Cm, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from config import NTT_BRAND, NTT_LOGO_PATH, OUTPUT_DIR
from core.models import CVData


# ---------- Colour helpers ----------

def _hex_to_rgb(hex_str: str) -> RGBColor:
    h = hex_str.lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


PRIMARY = _hex_to_rgb(NTT_BRAND["primary_color"])
SECONDARY = _hex_to_rgb(NTT_BRAND["secondary_color"])
ACCENT = _hex_to_rgb(NTT_BRAND["accent_color"])
TEXT_COLOR = _hex_to_rgb(NTT_BRAND["text_color"])


# ---------- Helper functions ----------

def _set_cell_shading(cell, color_hex: str):
    """Set background shading for a table cell."""
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), color_hex.lstrip("#"))
    shading.set(qn("w:val"), "clear")
    cell._tc.get_or_add_tcPr().append(shading)


def _add_horizontal_line(doc, color_hex: str = NTT_BRAND["primary_color"]):
    """Add a horizontal line paragraph."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), color_hex.lstrip("#"))
    pBdr.append(bottom)
    pPr.append(pBdr)


def _add_section_heading(doc, text: str, template: str):
    """Add a styled section heading."""
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.font.size = Pt(13)
    run.font.color.rgb = PRIMARY
    run.bold = True
    p.paragraph_format.space_before = Pt(14)
    p.paragraph_format.space_after = Pt(4)

    if template == "executive":
        run.font.size = Pt(14)
        run.font.color.rgb = PRIMARY
    elif template == "postcard":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    _add_horizontal_line(doc)
    return p


def _add_body_text(doc, text: str, bold: bool = False, template: str = "simple"):
    """Add a body text paragraph."""
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.font.size = Pt(10)
    run.font.color.rgb = TEXT_COLOR
    run.bold = bold
    p.paragraph_format.space_after = Pt(2)
    return p


# ---------- Main entry point ----------

def generate_docx(cv: CVData, output_path: Optional[Path] = None) -> Path:
    """Generate an NTT DATA branded DOCX CV.

    Args:
        cv: The CV data model.
        output_path: Optional output path; defaults to output/<name>.docx.

    Returns:
        Path to the generated DOCX file.
    """
    if output_path is None:
        safe_name = cv.identity.full_name.replace(" ", "_") or "cv"
        output_path = OUTPUT_DIR / f"{safe_name}.docx"

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    doc = Document()

    # Set default font
    style = doc.styles["Normal"]
    font = style.font
    font.name = "Calibri"
    font.size = Pt(10)

    # ---- Header section ----

    # Logo
    if NTT_LOGO_PATH.exists():
        logo_para = doc.add_paragraph()
        if cv.template == "postcard":
            logo_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        logo_run = logo_para.add_run()
        logo_run.add_picture(str(NTT_LOGO_PATH), width=Inches(1.8))

    # Name
    if cv.identity.full_name:
        p = doc.add_paragraph()
        run = p.add_run(cv.identity.full_name)
        run.font.size = Pt(22) if cv.template != "postcard" else Pt(18)
        run.font.color.rgb = SECONDARY
        run.bold = True
        if cv.template == "postcard":
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Role + org + location
    role_parts = filter(None, [
        cv.profile.current_role,
        cv.profile.current_organization,
        cv.profile.current_location,
    ])
    role_line = " | ".join(role_parts)
    if role_line:
        p = doc.add_paragraph()
        run = p.add_run(role_line)
        run.font.size = Pt(12)
        run.font.color.rgb = PRIMARY
        run.bold = True
        if cv.template == "postcard":
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Total experience
    if cv.identity.total_years_experience:
        _add_body_text(doc, f"Total Experience: {cv.identity.total_years_experience} years")

    # Portal ID
    if cv.identity.portal_id:
        _add_body_text(doc, f"Portal ID: {cv.identity.portal_id}")

    _add_horizontal_line(doc)

    # ---- Professional Summary ----
    if cv.summary.profile_summary:
        _add_section_heading(doc, "Professional Summary", cv.template)
        _add_body_text(doc, cv.summary.profile_summary)

    # ---- Target Roles ----
    if cv.summary.target_roles:
        _add_section_heading(doc, "Target Roles", cv.template)
        _add_body_text(doc, cv.summary.target_roles)

    # ---- Domain & Expertise ----
    if any([cv.domain.industries_domains, cv.domain.core_expertise, cv.domain.key_skills]):
        _add_section_heading(doc, "Domain & Expertise", cv.template)
        if cv.domain.industries_domains:
            _add_body_text(doc, f"Industries/Domains: {cv.domain.industries_domains}", bold=True)
        if cv.domain.core_expertise:
            _add_body_text(doc, f"Core Expertise: {cv.domain.core_expertise}", bold=True)
        if cv.domain.key_skills:
            _add_body_text(doc, f"Key Skills: {cv.domain.key_skills}", bold=True)

    # ---- Role-Specific Deep Dive ----
    if cv.deep_dive.answers:
        title = f"{cv.deep_dive.role_title} Deep Dive" if cv.deep_dive.role_title else "Role-Specific Details"
        if cv.deep_dive.focus:
            title += f" — {cv.deep_dive.focus}"
        _add_section_heading(doc, title, cv.template)

        from core.conversation import get_phase_questions
        from config import PHASE_DEEP_DIVE
        questions = get_phase_questions(PHASE_DEEP_DIVE, cv)

        for q_key in sorted(cv.deep_dive.answers.keys(), key=lambda x: int(x.replace("q", ""))):
            idx = int(q_key.replace("q", "")) - 1
            label = questions[idx] if idx < len(questions) else f"Q{idx + 1}"

            _add_body_text(doc, label, bold=True)
            _add_body_text(doc, cv.deep_dive.answers[q_key])

    # ---- Footer ----
    _add_horizontal_line(doc)
    p = doc.add_paragraph()
    run = p.add_run(NTT_BRAND["footer_text"])
    run.font.size = Pt(7)
    run.font.color.rgb = RGBColor(0x99, 0x99, 0x99)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # ---- Template-specific headers/footers ----
    if cv.template in ("postcard", "executive"):
        section = doc.sections[0]
        header = section.header
        hp = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
        hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        hr = hp.add_run("NTT DATA")
        hr.font.size = Pt(8)
        hr.font.color.rgb = PRIMARY

    doc.save(str(output_path))
    return output_path


def generate_docx_bytes(cv: CVData) -> bytes:
    """Generate DOCX and return as bytes (for API download)."""
    import tempfile
    safe_name = cv.identity.full_name.replace(" ", "_") or "cv"
    path = OUTPUT_DIR / f"{safe_name}.docx"
    generate_docx(cv, path)
    return path.read_bytes()